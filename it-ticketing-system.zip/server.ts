import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI, Type } from '@google/genai';
import { INITIAL_TICKETS, INITIAL_NOTIFICATIONS, INITIAL_AGENTS } from './src/data/mockData.ts';
import { Ticket, NotificationLog, TicketStatus, TicketComment, TicketPriority } from './src/types.ts';

const app = express();
const PORT = 3000;

app.use(express.json({ limit: '10mb' }));

// In-memory data store
let tickets: Ticket[] = [...INITIAL_TICKETS];
let notifications: NotificationLog[] = [...INITIAL_NOTIFICATIONS];
let ticketCounter = 1005;

// Lazy-initialized Gemini AI client
let aiClient: GoogleGenAI | null = null;
function getGeminiClient(): GoogleGenAI {
  if (!aiClient) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      console.warn("GEMINI_API_KEY is missing. AI features will fallback to smart template defaults.");
    }
    aiClient = new GoogleGenAI({
      apiKey: apiKey || '',
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  }
  return aiClient;
}

// Helper to create automated status & resolution notification emails
function dispatchAutomatedNotification(
  ticket: Ticket,
  type: 'TICKET_RECEIVED' | 'STATUS_UPDATE' | 'RESOLUTION_DETAILS' | 'COMMENT_ADDED',
  extraNote?: string
): NotificationLog {
  const notifId = `notif-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
  let subject = '';
  let bodyHtml = '';

  const headerBox = `
    <div style="background-color: #0f172a; color: #ffffff; padding: 20px; border-radius: 8px 8px 0 0; text-align: center;">
      <h2 style="margin: 0; font-size: 22px; font-weight: 700; tracking: -0.5px;">Enterprise IT Operations Desk</h2>
      <p style="margin: 6px 0 0 0; font-size: 13px; color: #94a3b8;">Automated IT Ticket Notification System</p>
    </div>
  `;

  const footerBox = `
    <div style="margin-top: 28px; padding-top: 18px; border-top: 1px solid #e2e8f0; text-align: center;">
      <p style="font-size: 12px; color: #94a3b8; margin: 0 0 6px 0;">Internal Enterprise IT Desk • Contact: support@enterprise.com</p>
      <p style="font-size: 11px; color: #cbd5e1; margin: 0;">This email was dispatched automatically based on ticket status changes.</p>
    </div>
  `;

  if (type === 'TICKET_RECEIVED') {
    subject = `[RECEIVED] Ticket ${ticket.id}: ${ticket.title}`;
    bodyHtml = `
      <div style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; max-width: 620px; margin: 0 auto; border: 1px solid #e2e8f0; border-radius: 12px; overflow: hidden; background-color: #ffffff; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05);">
        ${headerBox}
        <div style="padding: 24px; color: #334155; line-height: 1.6;">
          <p style="font-size: 16px; margin-top: 0;">Hi <strong>${ticket.employeeName}</strong>,</p>
          <p style="font-size: 14px;">Your IT service request has been received and logged into our queue under <strong>${ticket.id}</strong>.</p>
          
          <div style="background-color: #f8fafc; border: 1px solid #cbd5e1; border-radius: 8px; padding: 16px; margin: 20px 0;">
            <div style="font-size: 12px; font-weight: 700; color: #64748b; text-transform: uppercase; margin-bottom: 8px;">Ticket Overview</div>
            <p style="margin: 0 0 6px 0; font-size: 15px; font-weight: 600; color: #0f172a;">${ticket.title}</p>
            <p style="margin: 0 0 12px 0; font-size: 13px; color: #475569;">${ticket.description}</p>
            <div style="display: flex; gap: 16px; font-size: 12px; color: #64748b;">
              <span><strong>Category:</strong> ${ticket.category}</span> | 
              <span><strong>Priority:</strong> ${ticket.priority}</span> | 
              <span><strong>Department:</strong> ${ticket.department}</span>
            </div>
          </div>

          ${ticket.aiSuggestedFix ? `
            <div style="background-color: #eff6ff; border-left: 4px solid #3b82f6; padding: 14px; border-radius: 4px; margin: 20px 0;">
              <strong style="color: #1e40af; font-size: 13px;">💡 Instant AI Troubleshooting Suggestion:</strong>
              <p style="margin: 6px 0 0 0; font-size: 13px; color: #1e3a8a;">${ticket.aiSuggestedFix}</p>
            </div>
          ` : ''}

          <p style="font-size: 13px; color: #64748b;">An IT specialist will review your ticket shortly. You will receive automated status notifications as work progresses.</p>
          ${footerBox}
        </div>
      </div>
    `;
  } else if (type === 'STATUS_UPDATE') {
    subject = `[STATUS UPDATE] Ticket ${ticket.id} is now ${ticket.status.replace('_', ' ')}`;
    bodyHtml = `
      <div style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; max-width: 620px; margin: 0 auto; border: 1px solid #e2e8f0; border-radius: 12px; overflow: hidden; background-color: #ffffff; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05);">
        ${headerBox}
        <div style="padding: 24px; color: #334155; line-height: 1.6;">
          <p style="font-size: 16px; margin-top: 0;">Hi <strong>${ticket.employeeName}</strong>,</p>
          <p style="font-size: 14px;">The status of your ticket <strong>[${ticket.id}]</strong> was updated to <span style="display: inline-block; padding: 4px 10px; background-color: #e0f2fe; color: #0369a1; font-weight: 700; border-radius: 9999px; font-size: 12px;">${ticket.status.replace('_', ' ')}</span>.</p>
          
          <div style="background-color: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 16px; margin: 18px 0;">
            <p style="margin: 0 0 6px 0; font-size: 14px; font-weight: 600; color: #0f172a;">${ticket.title}</p>
            <p style="margin: 0; font-size: 13px; color: #475569;">Assigned Specialist: <strong>${ticket.assigneeName || 'Unassigned Queue'}</strong></p>
            ${extraNote ? `<p style="margin: 10px 0 0 0; font-size: 13px; color: #334155; border-top: 1px dashed #cbd5e1; padding-top: 8px;"><em>Note: ${extraNote}</em></p>` : ''}
          </div>

          <p style="font-size: 13px; color: #64748b;">You can track this request anytime on the internal IT Employee Portal.</p>
          ${footerBox}
        </div>
      </div>
    `;
  } else if (type === 'RESOLUTION_DETAILS') {
    subject = `✅ [RESOLVED & CLOSED] Ticket ${ticket.id}: Resolution Details & Confirmation`;
    bodyHtml = `
      <div style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; max-width: 620px; margin: 0 auto; border: 1px solid #e2e8f0; border-radius: 12px; overflow: hidden; background-color: #ffffff; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05);">
        ${headerBox}
        <div style="padding: 24px; color: #334155; line-height: 1.6;">
          <p style="font-size: 16px; margin-top: 0;">Dear <strong>${ticket.employeeName}</strong>,</p>
          <p style="font-size: 14px; color: #0f172a;">Your IT ticket <strong>[${ticket.id}]</strong> has been marked as <strong>${ticket.status}</strong> by IT Specialist <strong>${ticket.assigneeName || 'IT Operations Desk'}</strong>.</p>
          
          <div style="background-color: #f0fdf4; border: 1px solid #bbf7d0; border-radius: 8px; padding: 18px; margin: 20px 0;">
            <div style="font-size: 12px; font-weight: 700; color: #15803d; text-transform: uppercase; margin-bottom: 8px;">Resolution Details & Actions Taken</div>
            <p style="margin: 0; font-size: 14px; color: #166534; line-height: 1.6; white-space: pre-line;">${ticket.resolutionDetails || 'Issue diagnosed and solved by IT support team.'}</p>
          </div>

          <div style="background-color: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 16px; margin: 20px 0; text-align: center;">
            <p style="margin: 0 0 10px 0; font-size: 13px; font-weight: 600; color: #0f172a;">How satisfied are you with this resolution?</p>
            <p style="margin: 0; font-size: 12px; color: #64748b;">Please open the IT Portal to submit your 1-5 star CSAT feedback!</p>
          </div>

          <p style="font-size: 13px; color: #64748b;">If this issue was resolved prematurely or recurs, please log in to the portal to re-open this ticket within 48 hours.</p>
          ${footerBox}
        </div>
      </div>
    `;
  } else if (type === 'COMMENT_ADDED') {
    subject = `[NEW COMMENT] Ticket ${ticket.id}: New message from IT Support`;
    bodyHtml = `
      <div style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; max-width: 620px; margin: 0 auto; border: 1px solid #e2e8f0; border-radius: 12px; overflow: hidden; background-color: #ffffff;">
        ${headerBox}
        <div style="padding: 24px; color: #334155;">
          <p style="font-size: 15px; margin-top: 0;">Hi <strong>${ticket.employeeName}</strong>,</p>
          <p style="font-size: 14px;">A new comment was added to your ticket <strong>[${ticket.id}]</strong>:</p>
          <div style="background-color: #f1f5f9; border-left: 4px solid #0284c7; padding: 14px; margin: 16px 0; border-radius: 4px;">
            <p style="margin: 0; font-size: 13px; color: #0f172a;">${extraNote || 'New comment added.'}</p>
          </div>
          ${footerBox}
        </div>
      </div>
    `;
  }

  const notification: NotificationLog = {
    id: notifId,
    ticketId: ticket.id,
    ticketTitle: ticket.title,
    recipientEmail: ticket.employeeEmail,
    recipientName: ticket.employeeName,
    type,
    subject,
    bodyHtml,
    sentAt: new Date().toISOString(),
    status: 'DELIVERED',
  };

  notifications.unshift(notification);
  return notification;
}

// REST API ROUTES
app.get('/api/tickets', (req, res) => {
  const { status, category, priority, search } = req.query;
  let filtered = [...tickets];

  if (status && status !== 'ALL') {
    filtered = filtered.filter((t) => t.status === status);
  }
  if (category && category !== 'ALL') {
    filtered = filtered.filter((t) => t.category === category);
  }
  if (priority && priority !== 'ALL') {
    filtered = filtered.filter((t) => t.priority === priority);
  }
  if (search) {
    const q = (search as string).toLowerCase();
    filtered = filtered.filter(
      (t) =>
        t.id.toLowerCase().includes(q) ||
        t.title.toLowerCase().includes(q) ||
        t.description.toLowerCase().includes(q) ||
        t.employeeName.toLowerCase().includes(q) ||
        t.employeeEmail.toLowerCase().includes(q)
    );
  }

  // Sort newest first
  filtered.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  res.json(filtered);
});

app.post('/api/tickets', (req, res) => {
  const {
    title,
    description,
    employeeName,
    employeeEmail,
    department,
    locationOrDevice,
    category,
    priority,
    attachments,
  } = req.body;

  if (!title || !description || !employeeName || !employeeEmail) {
    return res.status(400).json({ error: 'Title, description, name, and email are required fields.' });
  }

  const newTicketId = `TICK-${ticketCounter++}`;
  const now = new Date().toISOString();

  const newTicket: Ticket = {
    id: newTicketId,
    title,
    description,
    employeeName,
    employeeEmail,
    department: department || 'General',
    locationOrDevice: locationOrDevice || '',
    category: category || 'Other',
    priority: priority || 'MEDIUM',
    status: 'NEW',
    createdAt: now,
    updatedAt: now,
    attachments: attachments || [],
    comments: [
      {
        id: `c-${Date.now()}`,
        authorName: employeeName,
        authorEmail: employeeEmail,
        authorRole: 'EMPLOYEE',
        message: `Issue ticket submitted. ${description}`,
        timestamp: now,
      },
    ],
    history: [
      {
        id: `h-${Date.now()}`,
        fromStatus: 'NEW',
        toStatus: 'NEW',
        updatedBy: employeeName,
        timestamp: now,
        note: 'Ticket created by employee',
      },
    ],
  };

  tickets.unshift(newTicket);

  // Dispatch confirmation notification email
  const notif = dispatchAutomatedNotification(newTicket, 'TICKET_RECEIVED');

  res.status(201).json({ ticket: newTicket, notificationSent: notif });
});

app.patch('/api/tickets/:id', (req, res) => {
  const { id } = req.params;
  const { status, assigneeName, assigneeEmail, priority, category, resolutionDetails } = req.body;

  const ticketIndex = tickets.findIndex((t) => t.id === id);
  if (ticketIndex === -1) {
    return res.status(404).json({ error: 'Ticket not found' });
  }

  const ticket = tickets[ticketIndex];
  const oldStatus = ticket.status;
  const now = new Date().toISOString();
  let updatedNotif: NotificationLog | undefined = undefined;

  if (status && status !== oldStatus) {
    ticket.status = status as TicketStatus;
    ticket.history.unshift({
      id: `h-${Date.now()}`,
      fromStatus: oldStatus,
      toStatus: status as TicketStatus,
      updatedBy: assigneeName || 'IT Admin',
      timestamp: now,
      note: `Status updated from ${oldStatus} to ${status}`,
    });

    if (status === 'RESOLVED' || status === 'CLOSED') {
      ticket.closedAt = now;
      if (resolutionDetails) {
        ticket.resolutionDetails = resolutionDetails;
      }
      updatedNotif = dispatchAutomatedNotification(ticket, 'RESOLUTION_DETAILS');
    } else {
      updatedNotif = dispatchAutomatedNotification(ticket, 'STATUS_UPDATE', `Status set to ${status}`);
    }
  }

  if (assigneeName !== undefined) ticket.assigneeName = assigneeName;
  if (assigneeEmail !== undefined) ticket.assigneeEmail = assigneeEmail;
  if (priority !== undefined) ticket.priority = priority as TicketPriority;
  if (category !== undefined) ticket.category = category;
  if (resolutionDetails !== undefined) ticket.resolutionDetails = resolutionDetails;

  ticket.updatedAt = now;
  tickets[ticketIndex] = ticket;

  res.json({ ticket, notificationSent: updatedNotif });
});

app.post('/api/tickets/:id/comments', (req, res) => {
  const { id } = req.params;
  const { authorName, authorEmail, authorRole, message, isInternalOnly } = req.body;

  const ticketIndex = tickets.findIndex((t) => t.id === id);
  if (ticketIndex === -1) {
    return res.status(404).json({ error: 'Ticket not found' });
  }

  const ticket = tickets[ticketIndex];
  const now = new Date().toISOString();

  const newComment: TicketComment = {
    id: `c-${Date.now()}`,
    authorName,
    authorEmail,
    authorRole,
    message,
    timestamp: now,
    isInternalOnly: !!isInternalOnly,
  };

  ticket.comments.push(newComment);
  ticket.updatedAt = now;

  let notif: NotificationLog | undefined = undefined;
  if (!isInternalOnly && authorRole === 'IT_AGENT') {
    notif = dispatchAutomatedNotification(ticket, 'COMMENT_ADDED', message);
  }

  res.json({ ticket, newComment, notificationSent: notif });
});

app.post('/api/tickets/:id/rate', (req, res) => {
  const { id } = req.params;
  const { rating, feedback } = req.body;

  const ticket = tickets.find((t) => t.id === id);
  if (!ticket) return res.status(404).json({ error: 'Ticket not found' });

  ticket.rating = rating;
  ticket.ratingFeedback = feedback || '';
  ticket.updatedAt = new Date().toISOString();

  res.json({ success: true, ticket });
});

app.get('/api/notifications', (req, res) => {
  res.json(notifications);
});

// AI Triage Endpoint (Gemini 3.6 Flash)
app.post('/api/ai/triage', async (req, res) => {
  const { title, description } = req.body;
  if (!title || !description) {
    return res.status(400).json({ error: 'Title and description required' });
  }

  try {
    const ai = getGeminiClient();
    const prompt = `You are an AI IT Operations Specialist. Analyze the following employee IT ticket and output structured JSON triaging data.
Ticket Title: "${title}"
Ticket Description: "${description}"

Categories available:
- "Hardware"
- "Software"
- "Network & VPN"
- "Access & Passwords"
- "Security & Compliance"
- "Printing & Audio/Visual"
- "Other"

Priorities available:
- "LOW"
- "MEDIUM"
- "HIGH"
- "CRITICAL"`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.6-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            category: { type: Type.STRING },
            priority: { type: Type.STRING },
            estimatedMinutesToResolve: { type: Type.NUMBER },
            summary: { type: Type.STRING },
            suggestedFix: { type: Type.STRING },
            recommendedSpecialty: { type: Type.STRING },
          },
          required: ['category', 'priority', 'summary', 'suggestedFix'],
        },
      },
    });

    const jsonText = response.text || '{}';
    const parsed = JSON.parse(jsonText);
    res.json(parsed);
  } catch (err: any) {
    console.error('Error calling Gemini AI Triage:', err);
    // Fallback response if API key is not present or error
    res.json({
      category: 'Software',
      priority: 'MEDIUM',
      estimatedMinutesToResolve: 30,
      summary: title,
      suggestedFix: 'Standard diagnostic recommended: Check cable connection, re-authenticate user credentials, and restart service daemon.',
      recommendedSpecialty: 'IT Service Desk',
    });
  }
});

// AI Resolution Drafter Endpoint (Gemini 3.6 Flash)
app.post('/api/ai/draft-resolution', async (req, res) => {
  const { ticketTitle, ticketDescription, roughNotes, agentName } = req.body;

  try {
    const ai = getGeminiClient();
    const prompt = `You are an IT Support Specialist named ${agentName || 'IT Specialist'}. Draft a formal, precise resolution summary to send to the employee once their ticket is closed.
Ticket Issue: "${ticketTitle}"
Issue Details: "${ticketDescription}"
IT Agent Rough Notes: "${roughNotes || 'Resolved the underlying system issue and verified functionality.'}"

Create a clean, empathetic, step-by-step resolution report text. Keep it professional, structured, and under 150 words.`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.6-flash',
      contents: prompt,
    });

    res.json({ resolutionDetails: response.text });
  } catch (err) {
    res.json({
      resolutionDetails: `Issue solved by IT Specialist. ${roughNotes || 'Diagnosed root cause, updated configurations, and verified system functionality with user.'}`,
    });
  }
});

async function startServer() {
  // Vite integration
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
