import React, { useState } from 'react';
import { Ticket, TicketCategory, TicketPriority, TicketAttachment } from '../types';
import { DEPARTMENTS } from '../data/mockData';
import {
  Send,
  Sparkles,
  Paperclip,
  X,
  FileText,
  Clock,
  CheckCircle,
  AlertCircle,
  User,
  Building,
  Laptop,
  CheckCircle2,
  ChevronRight,
  Star,
  RefreshCw,
  Mail,
  HelpCircle,
  Search,
} from 'lucide-react';

interface EmployeePortalProps {
  tickets: Ticket[];
  onSubmitTicket: (ticketData: any) => Promise<void>;
  onSelectTicket: (ticket: Ticket) => void;
  onRateTicket: (ticketId: string) => void;
  isLoading: boolean;
}

export const EmployeePortal: React.FC<EmployeePortalProps> = ({
  tickets,
  onSubmitTicket,
  onSelectTicket,
  onRateTicket,
  isLoading,
}) => {
  const [activeTab, setActiveTab] = useState<'SUBMIT' | 'MY_TICKETS'>('SUBMIT');

  // Form State
  const [employeeName, setEmployeeName] = useState('David Miller');
  const [employeeEmail, setEmployeeEmail] = useState('david.miller@enterprise.com');
  const [department, setDepartment] = useState('Engineering & Development');
  const [locationOrDevice, setLocationOrDevice] = useState('MacBook Pro 16" (MBP-2024-889)');
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState<TicketCategory>('Software');
  const [priority, setPriority] = useState<TicketPriority>('MEDIUM');
  const [description, setDescription] = useState('');
  const [attachments, setAttachments] = useState<TicketAttachment[]>([]);

  // AI Instant Assistant State
  const [aiAnalyzing, setAiAnalyzing] = useState(false);
  const [aiSuggestion, setAiSuggestion] = useState<{
    suggestedFix?: string;
    category?: string;
    priority?: string;
  } | null>(null);

  // Search filter for My Tickets
  const [myTicketsSearch, setMyTicketsSearch] = useState('');

  // Handle file drop/upload simulation
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files) return;

    const newAttachments: TicketAttachment[] = Array.from(files).map((file: File, idx) => ({
      id: `att-${Date.now()}-${idx}`,
      name: file.name,
      size: `${(file.size / 1024).toFixed(1)} KB`,
      type: file.type || 'document',
    }));

    setAttachments((prev) => [...prev, ...newAttachments]);
  };

  const removeAttachment = (id: string) => {
    setAttachments((prev) => prev.filter((a) => a.id !== id));
  };

  // Get AI Instant Assistance before submitting
  const handleFetchAiAssist = async () => {
    if (!title || !description) return;
    setAiAnalyzing(true);
    try {
      const res = await fetch('/api/ai/triage', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ title, description }),
      });
      const data = await res.json();
      setAiSuggestion(data);
      if (data.category) setCategory(data.category as TicketCategory);
      if (data.priority) setPriority(data.priority as TicketPriority);
    } catch (err) {
      console.error(err);
    } finally {
      setAiAnalyzing(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !description.trim()) return;

    await onSubmitTicket({
      title,
      description,
      employeeName,
      employeeEmail,
      department,
      locationOrDevice,
      category,
      priority,
      attachments,
    });

    // Reset Form
    setTitle('');
    setDescription('');
    setAttachments([]);
    setAiSuggestion(null);
    setActiveTab('MY_TICKETS');
  };

  // Filter My Tickets
  const myTickets = tickets.filter(
    (t) =>
      t.employeeEmail.toLowerCase() === employeeEmail.toLowerCase() ||
      t.employeeName.toLowerCase().includes(employeeName.toLowerCase())
  );

  const filteredMyTickets = myTickets.filter(
    (t) =>
      t.id.toLowerCase().includes(myTicketsSearch.toLowerCase()) ||
      t.title.toLowerCase().includes(myTicketsSearch.toLowerCase()) ||
      t.status.toLowerCase().includes(myTicketsSearch.toLowerCase())
  );

  return (
    <div className="space-y-6">
      {/* Employee Header & Tab Bar */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900 flex items-center space-x-2">
            <span>Employee IT Helpdesk Portal</span>
            <span className="text-xs font-normal text-emerald-700 bg-emerald-50 border border-emerald-200 px-2.5 py-0.5 rounded-full">
              Automated Status Emailing Active
            </span>
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Submit IT issues, receive automated resolution emails, and track status in real-time.
          </p>
        </div>

        <div className="flex bg-slate-100 p-1 rounded-xl border border-slate-200">
          <button
            onClick={() => setActiveTab('SUBMIT')}
            className={`px-4 py-2 rounded-lg text-xs font-semibold transition-all flex items-center space-x-1.5 ${
              activeTab === 'SUBMIT'
                ? 'bg-white text-blue-700 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Send className="w-3.5 h-3.5" />
            <span>Request New Issue</span>
          </button>
          <button
            onClick={() => setActiveTab('MY_TICKETS')}
            className={`px-4 py-2 rounded-lg text-xs font-semibold transition-all flex items-center space-x-1.5 relative ${
              activeTab === 'MY_TICKETS'
                ? 'bg-white text-blue-700 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <FileText className="w-3.5 h-3.5" />
            <span>My Submitted Requests</span>
            <span className="bg-blue-600 text-white text-[10px] px-1.5 py-0.2 rounded-full font-bold ml-1">
              {myTickets.length}
            </span>
          </button>
        </div>
      </div>

      {/* TAB 1: SUBMIT NEW ISSUE */}
      {activeTab === 'SUBMIT' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main Form */}
          <div className="lg:col-span-2 bg-white p-6 rounded-2xl border border-slate-200/80 shadow-xs space-y-6">
            <div className="border-b border-slate-100 pb-4">
              <h2 className="text-base font-bold text-slate-900">Submit IT Issue & Request Support</h2>
              <p className="text-xs text-slate-500 mt-0.5">
                Fill in the details below. Our automated system will log your request and send confirmation to your email.
              </p>
            </div>

            <form onSubmit={handleSubmit} className="space-y-5">
              {/* Employee Info Row */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 bg-slate-50 p-4 rounded-xl border border-slate-200/70">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Your Full Name</label>
                  <div className="relative">
                    <User className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
                    <input
                      type="text"
                      value={employeeName}
                      onChange={(e) => setEmployeeName(e.target.value)}
                      required
                      className="w-full pl-9 pr-3 py-2 text-xs bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-hidden"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Work Email (For Auto-Updates)</label>
                  <div className="relative">
                    <Mail className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
                    <input
                      type="email"
                      value={employeeEmail}
                      onChange={(e) => setEmployeeEmail(e.target.value)}
                      required
                      className="w-full pl-9 pr-3 py-2 text-xs bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-hidden"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Department</label>
                  <select
                    value={department}
                    onChange={(e) => setDepartment(e.target.value)}
                    className="w-full px-3 py-2 text-xs bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-hidden"
                  >
                    {DEPARTMENTS.map((d) => (
                      <option key={d} value={d}>
                        {d}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Equipment ID / Location</label>
                  <div className="relative">
                    <Laptop className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
                    <input
                      type="text"
                      placeholder="e.g. MBP-2024 / Desk 4B"
                      value={locationOrDevice}
                      onChange={(e) => setLocationOrDevice(e.target.value)}
                      className="w-full pl-9 pr-3 py-2 text-xs bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-hidden"
                    />
                  </div>
                </div>
              </div>

              {/* Issue Category & Priority Row */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Issue Category</label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value as TicketCategory)}
                    className="w-full px-3 py-2 text-xs bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-hidden"
                  >
                    <option value="Software">Software & Apps</option>
                    <option value="Hardware">Hardware & Display</option>
                    <option value="Network & VPN">Network & VPN</option>
                    <option value="Access & Passwords">Access & Passwords / SSO</option>
                    <option value="Security & Compliance">Security & Compliance</option>
                    <option value="Printing & Audio/Visual">Printing & Audio/Visual</option>
                    <option value="Other">Other Request</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Urgency / Impact</label>
                  <select
                    value={priority}
                    onChange={(e) => setPriority(e.target.value as TicketPriority)}
                    className="w-full px-3 py-2 text-xs bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-hidden"
                  >
                    <option value="LOW">Low (Minor inconvenience / Query)</option>
                    <option value="MEDIUM">Medium (Normal work impact)</option>
                    <option value="HIGH">High (Major task blocked)</option>
                    <option value="CRITICAL">Critical (System down / Security outage)</option>
                  </select>
                </div>
              </div>

              {/* Issue Title */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Issue Title / Subject</label>
                <input
                  type="text"
                  placeholder="e.g. Cannot connect to VPN after latest macOS update"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  required
                  className="w-full px-3 py-2 text-xs bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-hidden"
                />
              </div>

              {/* Detailed Description */}
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="block text-xs font-semibold text-slate-700">Detailed Description & Error Messages</label>
                  <button
                    type="button"
                    onClick={handleFetchAiAssist}
                    disabled={!title || !description || aiAnalyzing}
                    className="text-[11px] text-blue-600 hover:text-blue-800 font-semibold flex items-center space-x-1 disabled:opacity-40"
                  >
                    <Sparkles className="w-3.5 h-3.5 text-blue-600" />
                    <span>{aiAnalyzing ? 'AI Analyzing...' : '✨ Get AI Instant Self-Fix Suggestions'}</span>
                  </button>
                </div>
                <textarea
                  rows={4}
                  placeholder="Describe what happened, step-by-step actions taken, and exact error codes..."
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  required
                  className="w-full p-3 text-xs bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-hidden"
                />
              </div>

              {/* Attachments Section */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Attachments (Screenshots / Error Logs)</label>
                <div className="flex items-center space-x-3">
                  <label className="cursor-pointer flex items-center space-x-2 bg-slate-100 hover:bg-slate-200 text-slate-700 px-3.5 py-2 rounded-lg text-xs font-semibold border border-slate-300 transition-colors">
                    <Paperclip className="w-4 h-4 text-slate-500" />
                    <span>Attach Files</span>
                    <input type="file" multiple onChange={handleFileUpload} className="hidden" />
                  </label>
                  <span className="text-xs text-slate-400">Supported: PNG, JPG, PDF, TXT logs</span>
                </div>

                {/* Attachment Chips */}
                {attachments.length > 0 && (
                  <div className="flex flex-wrap gap-2 mt-3">
                    {attachments.map((att) => (
                      <div
                        key={att.id}
                        className="flex items-center space-x-2 bg-slate-100 border border-slate-200 px-3 py-1 rounded-lg text-xs"
                      >
                        <FileText className="w-3.5 h-3.5 text-blue-600" />
                        <span className="font-medium text-slate-700 max-w-[120px] truncate">{att.name}</span>
                        <span className="text-[10px] text-slate-400">({att.size})</span>
                        <button
                          type="button"
                          onClick={() => removeAttachment(att.id)}
                          className="text-slate-400 hover:text-red-500"
                        >
                          <X className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Submit Button */}
              <div className="pt-2 border-t border-slate-100 flex justify-end">
                <button
                  type="submit"
                  disabled={isLoading}
                  className="w-full sm:w-auto bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white font-bold px-6 py-2.5 rounded-xl text-xs shadow-md shadow-blue-500/20 flex items-center justify-center space-x-2 transition-all"
                >
                  <Send className="w-4 h-4" />
                  <span>Submit Request & Trigger Auto-Email Confirmation</span>
                </button>
              </div>
            </form>
          </div>

          {/* Right Column: AI Troubleshooting & Guidance */}
          <div className="space-y-5">
            {/* AI Instant Suggestion Box */}
            <div className="bg-gradient-to-br from-indigo-900 to-slate-900 text-white p-5 rounded-2xl shadow-md border border-indigo-700/50 relative overflow-hidden">
              <div className="flex items-center space-x-2 text-indigo-300 text-xs font-bold uppercase tracking-wider mb-2">
                <Sparkles className="w-4 h-4 text-cyan-400" />
                <span>AI Auto-Triage & Instant Assistance</span>
              </div>

              {aiAnalyzing ? (
                <div className="py-8 text-center space-y-2">
                  <RefreshCw className="w-6 h-6 text-cyan-400 animate-spin mx-auto" />
                  <p className="text-xs text-slate-300">Gemini is analyzing issue details and finding self-help solutions...</p>
                </div>
              ) : aiSuggestion ? (
                <div className="space-y-3 text-xs">
                  <div className="p-3 bg-indigo-950/80 rounded-xl border border-indigo-700/60">
                    <p className="font-semibold text-cyan-300 mb-1">Recommended Category & Priority:</p>
                    <div className="flex items-center space-x-2">
                      <span className="bg-indigo-600 text-white px-2 py-0.5 rounded-md font-bold">
                        {aiSuggestion.category}
                      </span>
                      <span className="bg-amber-500/20 text-amber-300 border border-amber-500/40 px-2 py-0.5 rounded-md font-bold">
                        {aiSuggestion.priority}
                      </span>
                    </div>
                  </div>

                  {aiSuggestion.suggestedFix && (
                    <div className="p-3 bg-slate-800/80 rounded-xl border border-slate-700 text-slate-200">
                      <p className="font-semibold text-emerald-400 mb-1">💡 Suggested Quick Troubleshooting Step:</p>
                      <p className="leading-relaxed text-slate-300">{aiSuggestion.suggestedFix}</p>
                    </div>
                  )}

                  <p className="text-[11px] text-slate-400">
                    If this solution works, you can close this window! Otherwise, submit your request above and IT staff will resolve it.
                  </p>
                </div>
              ) : (
                <div className="text-xs text-slate-300 space-y-2">
                  <p className="leading-relaxed">
                    As you type your issue title and description, click <strong className="text-cyan-300">"Get AI Instant Self-Fix Suggestions"</strong> to receive immediate AI troubleshooting guidance.
                  </p>
                  <div className="pt-3 border-t border-indigo-800/80 space-y-1.5 text-[11px] text-slate-400">
                    <div className="flex items-center space-x-2">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                      <span>Instant Ticket ID generation</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                      <span>Automated email receipt sent to {employeeEmail}</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                      <span>Full email resolution summary upon closure</span>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Helpdesk SLA Info */}
            <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs space-y-3">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 flex items-center space-x-2">
                <Clock className="w-4 h-4 text-blue-600" />
                <span>Service Level Expectations</span>
              </h3>
              <div className="space-y-2 text-xs">
                <div className="flex justify-between items-center py-1 border-b border-slate-100">
                  <span className="text-slate-600 font-medium">Critical / Blocker Issues:</span>
                  <span className="font-bold text-amber-600">&lt; 1 Hour SLA</span>
                </div>
                <div className="flex justify-between items-center py-1 border-b border-slate-100">
                  <span className="text-slate-600 font-medium">Normal / High Priority:</span>
                  <span className="font-bold text-blue-600">&lt; 4 Hours SLA</span>
                </div>
                <div className="flex justify-between items-center py-1">
                  <span className="text-slate-600 font-medium">Standard Requests:</span>
                  <span className="font-bold text-slate-700">&lt; 24 Hours SLA</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: MY SUBMITTED REQUESTS */}
      {activeTab === 'MY_TICKETS' && (
        <div className="space-y-4">
          {/* Search bar */}
          <div className="bg-white p-4 rounded-xl border border-slate-200/80 shadow-xs flex items-center justify-between">
            <div className="relative flex-1 max-w-md">
              <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
              <input
                type="text"
                placeholder="Search my tickets by ID, title or status..."
                value={myTicketsSearch}
                onChange={(e) => setMyTicketsSearch(e.target.value)}
                className="w-full pl-9 pr-4 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500 outline-hidden"
              />
            </div>
            <span className="text-xs text-slate-500 font-medium">
              Showing {filteredMyTickets.length} of {myTickets.length} submitted requests
            </span>
          </div>

          {/* Ticket List Cards */}
          {filteredMyTickets.length === 0 ? (
            <div className="bg-white p-12 text-center rounded-2xl border border-slate-200/80">
              <FileText className="w-10 h-10 text-slate-300 mx-auto mb-2" />
              <h3 className="text-sm font-bold text-slate-700">No Tickets Found</h3>
              <p className="text-xs text-slate-400 mt-1">
                You haven't submitted any tickets matching this search criteria.
              </p>
              <button
                onClick={() => setActiveTab('SUBMIT')}
                className="mt-4 bg-blue-600 text-white font-semibold text-xs px-4 py-2 rounded-lg"
              >
                Submit New IT Ticket
              </button>
            </div>
          ) : (
            <div className="space-y-3">
              {filteredMyTickets.map((ticket) => {
                const isResolved = ticket.status === 'RESOLVED' || ticket.status === 'CLOSED';
                return (
                  <div
                    key={ticket.id}
                    className="bg-white p-5 rounded-xl border border-slate-200/80 shadow-xs hover:shadow-md transition-all space-y-4"
                  >
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 pb-3">
                      <div className="flex items-center space-x-3">
                        <span className="font-mono text-xs font-bold text-slate-900 bg-slate-100 px-2.5 py-1 rounded-md border border-slate-200">
                          {ticket.id}
                        </span>
                        <h3 className="font-bold text-sm text-slate-900 hover:text-blue-600 transition-colors">
                          {ticket.title}
                        </h3>
                      </div>

                      {/* Status Badge */}
                      <div className="flex items-center space-x-2">
                        <span
                          className={`text-xs font-bold px-3 py-1 rounded-full border ${
                            ticket.status === 'NEW'
                              ? 'bg-blue-50 text-blue-700 border-blue-200'
                              : ticket.status === 'IN_PROGRESS'
                              ? 'bg-amber-50 text-amber-700 border-amber-200'
                              : ticket.status === 'PENDING_USER'
                              ? 'bg-purple-50 text-purple-700 border-purple-200'
                              : 'bg-emerald-50 text-emerald-700 border-emerald-200'
                          }`}
                        >
                          {ticket.status.replace('_', ' ')}
                        </span>
                      </div>
                    </div>

                    <p className="text-xs text-slate-600 line-clamp-2">{ticket.description}</p>

                    {/* Resolution Box if resolved */}
                    {isResolved && ticket.resolutionDetails && (
                      <div className="bg-emerald-50/70 border border-emerald-200/80 rounded-xl p-3 text-xs space-y-1.5">
                        <div className="flex items-center justify-between text-emerald-800 font-bold">
                          <span className="flex items-center space-x-1.5">
                            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                            <span>Official Resolution Summary (Auto-Emailed)</span>
                          </span>
                          <span className="text-[10px] text-emerald-700">
                            By {ticket.assigneeName || 'IT Support Specialist'}
                          </span>
                        </div>
                        <p className="text-emerald-950 font-medium leading-relaxed">{ticket.resolutionDetails}</p>
                      </div>
                    )}

                    {/* Footer Info */}
                    <div className="flex flex-wrap items-center justify-between text-xs text-slate-500 pt-1 border-t border-slate-100">
                      <div className="flex items-center space-x-4">
                        <span>
                          <strong>Category:</strong> {ticket.category}
                        </span>
                        <span>
                          <strong>Assigned:</strong> {ticket.assigneeName || 'Queue'}
                        </span>
                        <span>
                          <strong>Submitted:</strong> {new Date(ticket.createdAt).toLocaleDateString()}
                        </span>
                      </div>

                      <div className="flex items-center space-x-2 mt-2 sm:mt-0">
                        {isResolved && !ticket.rating && (
                          <button
                            onClick={() => onRateTicket(ticket.id)}
                            className="bg-amber-500 hover:bg-amber-600 text-white font-semibold px-3 py-1 rounded-lg text-xs flex items-center space-x-1 shadow-xs"
                          >
                            <Star className="w-3.5 h-3.5 fill-current" />
                            <span>Rate CSAT</span>
                          </button>
                        )}

                        {ticket.rating && (
                          <span className="flex items-center space-x-1 text-amber-600 font-bold bg-amber-50 px-2.5 py-1 rounded-lg border border-amber-200">
                            <Star className="w-3.5 h-3.5 fill-current text-amber-500" />
                            <span>{ticket.rating} / 5 Stars</span>
                          </span>
                        )}

                        <button
                          onClick={() => onSelectTicket(ticket)}
                          className="bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold px-3 py-1 rounded-lg text-xs flex items-center space-x-1 transition-colors"
                        >
                          <span>View Full Details & Timeline</span>
                          <ChevronRight className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
