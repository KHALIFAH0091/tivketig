import React from 'react';
import { Ticket, NotificationLog } from '../types';
import { Ticket as TicketIcon, Clock, CheckCircle2, Mail, AlertTriangle, ShieldCheck } from 'lucide-react';

interface MetricsBarProps {
  tickets: Ticket[];
  notifications: NotificationLog[];
}

export const MetricsBar: React.FC<MetricsBarProps> = ({ tickets, notifications }) => {
  const openCount = tickets.filter((t) => t.status === 'NEW' || t.status === 'IN_PROGRESS' || t.status === 'PENDING_USER').length;
  const criticalCount = tickets.filter((t) => t.priority === 'CRITICAL' && t.status !== 'CLOSED' && t.status !== 'RESOLVED').length;
  const resolvedCount = tickets.filter((t) => t.status === 'RESOLVED' || t.status === 'CLOSED').length;
  const totalEmailsSent = notifications.length;

  // Calculate avg rating
  const ratedTickets = tickets.filter((t) => t.rating && t.rating > 0);
  const avgRating = ratedTickets.length
    ? (ratedTickets.reduce((sum, t) => sum + (t.rating || 0), 0) / ratedTickets.length).toFixed(1)
    : '5.0';

  return (
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
      {/* Active Queue */}
      <div className="bg-white p-4 rounded-xl border border-slate-200/80 shadow-xs flex items-center justify-between">
        <div>
          <p className="text-xs font-medium text-slate-500 uppercase tracking-wider">Active Open Queue</p>
          <div className="flex items-baseline space-x-2 mt-1">
            <span className="text-2xl font-bold text-slate-900">{openCount}</span>
            <span className="text-xs text-slate-500">tickets pending</span>
          </div>
        </div>
        <div className="p-3 bg-blue-50 text-blue-600 rounded-xl">
          <TicketIcon className="w-5 h-5" />
        </div>
      </div>

      {/* Critical Escalations */}
      <div className="bg-white p-4 rounded-xl border border-slate-200/80 shadow-xs flex items-center justify-between">
        <div>
          <p className="text-xs font-medium text-slate-500 uppercase tracking-wider">Critical Escalations</p>
          <div className="flex items-baseline space-x-2 mt-1">
            <span className={`text-2xl font-bold ${criticalCount > 0 ? 'text-amber-600' : 'text-slate-900'}`}>
              {criticalCount}
            </span>
            <span className="text-xs text-slate-500">high priority</span>
          </div>
        </div>
        <div className={`p-3 rounded-xl ${criticalCount > 0 ? 'bg-amber-50 text-amber-600' : 'bg-slate-50 text-slate-500'}`}>
          <AlertTriangle className="w-5 h-5" />
        </div>
      </div>

      {/* Resolved & Closed */}
      <div className="bg-white p-4 rounded-xl border border-slate-200/80 shadow-xs flex items-center justify-between">
        <div>
          <p className="text-xs font-medium text-slate-500 uppercase tracking-wider">Resolved & CSAT</p>
          <div className="flex items-baseline space-x-2 mt-1">
            <span className="text-2xl font-bold text-emerald-600">{resolvedCount}</span>
            <span className="text-xs font-semibold text-amber-500 bg-amber-50 px-1.5 py-0.5 rounded">
              ★ {avgRating} CSAT
            </span>
          </div>
        </div>
        <div className="p-3 bg-emerald-50 text-emerald-600 rounded-xl">
          <CheckCircle2 className="w-5 h-5" />
        </div>
      </div>

      {/* Auto Email Notifications */}
      <div className="bg-white p-4 rounded-xl border border-slate-200/80 shadow-xs flex items-center justify-between">
        <div>
          <p className="text-xs font-medium text-slate-500 uppercase tracking-wider">Automated Email Dispatches</p>
          <div className="flex items-baseline space-x-2 mt-1">
            <span className="text-2xl font-bold text-indigo-600">{totalEmailsSent}</span>
            <span className="text-xs text-emerald-600 font-medium">100% delivered</span>
          </div>
        </div>
        <div className="p-3 bg-indigo-50 text-indigo-600 rounded-xl">
          <Mail className="w-5 h-5" />
        </div>
      </div>
    </div>
  );
};
