import React from 'react';
import { UserRole } from '../types';
import { ShieldCheck, Mail, Plus, User, Wrench, Sparkles } from 'lucide-react';

interface HeaderProps {
  activeRole: UserRole;
  setActiveRole: (role: UserRole) => void;
  onOpenNewTicket: () => void;
  onOpenNotifications: () => void;
  unreadCount: number;
}

export const Header: React.FC<HeaderProps> = ({
  activeRole,
  setActiveRole,
  onOpenNewTicket,
  onOpenNotifications,
  unreadCount,
}) => {
  return (
    <header className="bg-slate-900 border-b border-slate-800 text-white sticky top-0 z-30 shadow-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        {/* Brand Logo */}
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-blue-600 via-indigo-600 to-cyan-500 flex items-center justify-center shadow-lg shadow-blue-500/20">
            <ShieldCheck className="w-6 h-6 text-white" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <span className="font-bold text-lg tracking-tight text-white">Enterprise IT Desk</span>
              <span className="bg-blue-500/20 text-blue-300 border border-blue-500/30 text-[10px] font-semibold px-2 py-0.5 rounded-full">
                Auto-Notify v2.4
              </span>
            </div>
            <p className="text-xs text-slate-400">Automated Ticketing & Resolution Operations</p>
          </div>
        </div>

        {/* Center / Role Switcher */}
        <div className="hidden md:flex items-center p-1 bg-slate-800/80 rounded-xl border border-slate-700/60">
          <button
            onClick={() => setActiveRole('EMPLOYEE')}
            className={`flex items-center space-x-2 px-4 py-1.5 rounded-lg text-xs font-medium transition-all ${
              activeRole === 'EMPLOYEE'
                ? 'bg-blue-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-700/50'
            }`}
          >
            <User className="w-3.5 h-3.5" />
            <span>Employee Portal</span>
          </button>
          <button
            onClick={() => setActiveRole('IT_ADMIN')}
            className={`flex items-center space-x-2 px-4 py-1.5 rounded-lg text-xs font-medium transition-all ${
              activeRole === 'IT_ADMIN'
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-700/50'
            }`}
          >
            <Wrench className="w-3.5 h-3.5" />
            <span>IT Staff Workspace</span>
          </button>
        </div>

        {/* Right Action Controls */}
        <div className="flex items-center space-x-3">
          {/* Notification / Email Center Button */}
          <button
            onClick={onOpenNotifications}
            className="relative flex items-center space-x-2 bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 px-3.5 py-1.5 rounded-lg text-xs font-medium transition-colors"
            title="View Automated Notification Email Logs"
          >
            <Mail className="w-4 h-4 text-cyan-400" />
            <span className="hidden sm:inline">Automated Email Logs</span>
            {unreadCount > 0 && (
              <span className="bg-emerald-500 text-slate-950 font-bold text-[10px] px-1.5 py-0.2 rounded-full">
                {unreadCount}
              </span>
            )}
          </button>

          {/* New Ticket Button */}
          <button
            onClick={onOpenNewTicket}
            className="flex items-center space-x-1.5 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white px-4 py-1.5 rounded-lg text-xs font-semibold shadow-md shadow-blue-600/20 transition-all transform hover:-translate-y-0.5 active:translate-y-0"
          >
            <Plus className="w-4 h-4" />
            <span>Submit IT Request</span>
          </button>
        </div>
      </div>

      {/* Mobile Role Bar */}
      <div className="md:hidden flex border-t border-slate-800 bg-slate-950 px-4 py-1.5 justify-around text-xs">
        <button
          onClick={() => setActiveRole('EMPLOYEE')}
          className={`px-3 py-1 rounded-md ${
            activeRole === 'EMPLOYEE' ? 'bg-blue-600 text-white font-medium' : 'text-slate-400'
          }`}
        >
          Employee Portal
        </button>
        <button
          onClick={() => setActiveRole('IT_ADMIN')}
          className={`px-3 py-1 rounded-md ${
            activeRole === 'IT_ADMIN' ? 'bg-indigo-600 text-white font-medium' : 'text-slate-400'
          }`}
        >
          IT Staff Workspace
        </button>
      </div>
    </header>
  );
};
