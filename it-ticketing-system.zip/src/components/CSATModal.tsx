import React, { useState } from 'react';
import { Star, X, CheckCircle, Send } from 'lucide-react';

interface CSATModalProps {
  ticketId: string;
  onClose: () => void;
  onSubmitRating: (ticketId: string, rating: number, feedback: string) => Promise<void>;
}

export const CSATModal: React.FC<CSATModalProps> = ({ ticketId, onClose, onSubmitRating }) => {
  const [rating, setRating] = useState(5);
  const [hoverRating, setHoverRating] = useState(0);
  const [feedback, setFeedback] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    await onSubmitRating(ticketId, rating, feedback);
    setSubmitting(false);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white w-full max-w-md rounded-2xl shadow-2xl border border-slate-200 p-6 space-y-5">
        <div className="flex items-center justify-between border-b border-slate-100 pb-3">
          <div>
            <h3 className="text-base font-bold text-slate-900">IT Support CSAT Feedback</h3>
            <p className="text-xs text-slate-500">Rate resolution quality for ticket [{ticketId}]</p>
          </div>
          <button onClick={onClose} className="p-1 rounded-lg text-slate-400 hover:text-slate-700">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Star Rating selector */}
          <div className="text-center space-y-2">
            <p className="text-xs font-semibold text-slate-700">How would you rate the resolution speed & service?</p>
            <div className="flex justify-center items-center space-x-2">
              {[1, 2, 3, 4, 5].map((star) => (
                <button
                  key={star}
                  type="button"
                  onMouseEnter={() => setHoverRating(star)}
                  onMouseLeave={() => setHoverRating(0)}
                  onClick={() => setRating(star)}
                  className="p-1 transition-transform transform hover:scale-110"
                >
                  <Star
                    className={`w-8 h-8 ${
                      star <= (hoverRating || rating)
                        ? 'text-amber-400 fill-amber-400'
                        : 'text-slate-200 fill-slate-100'
                    }`}
                  />
                </button>
              ))}
            </div>
            <p className="text-xs font-bold text-amber-600">
              {rating === 5 ? 'Excellent 🌟🌟🌟🌟🌟' : rating === 4 ? 'Very Good 👍' : rating === 3 ? 'Satisfactory' : 'Needs Improvement'}
            </p>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Optional Feedback / Comments</label>
            <textarea
              rows={3}
              placeholder="Tell us what went well or how we can improve our IT support..."
              value={feedback}
              onChange={(e) => setFeedback(e.target.value)}
              className="w-full p-3 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-amber-500 outline-hidden"
            />
          </div>

          <button
            type="submit"
            disabled={submitting}
            className="w-full bg-amber-500 hover:bg-amber-600 text-white font-bold py-2.5 rounded-xl text-xs shadow-md shadow-amber-500/20 flex items-center justify-center space-x-2 transition-all"
          >
            <Send className="w-4 h-4" />
            <span>Submit CSAT Rating</span>
          </button>
        </form>
      </div>
    </div>
  );
};
