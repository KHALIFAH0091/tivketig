import React, { useState } from 'react';
import { Ticket, TicketStatus, TicketPriority, TicketCategory, ITAgent } from '../types';
import { INITIAL_AGENTS } from '../data/mockData';
import {
  X,
  User,
  Clock,
  Sparkles,
  Send,
  CheckCircle2,
  AlertTriangle,
  Mail,
  FileText,
  Lock,
  MessageSquare,
  History,
  ShieldAlert,
  Paperclip,
  Check,
  RefreshCw,
  Zap,
} from 'lucide-react';

interface TicketDetailModalProps {
  ticket: Ticket | null;
  onClose: () => void;
  onUpdateTicket: (
    ticketId: string,
    updates: {
      status?: TicketStatus;
      assigneeName?: string;
      assigneeEmail?: string;
      priority?: TicketPriority;
      category?: TicketCategory;
      resolutionDetails?: string;
    }
  ) => Promise<void>;
  onAddComment: (
    ticketId: string,
    comment: {
      authorName: string;
      authorEmail: string;
      authorRole: 'EMPLOYEE' | 'IT_AGENT';
      message: string;
      isInternalOnly?: boolean;
    }
  ) => Promise<void>;
  currentUserRole: 'EMPLOYEE' | 'IT_ADMIN';
}

export const TicketDetailModal: React.FC<TicketDetailModalProps> = ({
  ticket,
  onClose,
  onUpdateTicket,
  onAddComment,
  currentUserRole,
}) => {
  if (!ticket) return null;

  // Local state
  const [status, setStatus] = useState<TicketStatus>(ticket.status);
  const [priority, setPriority] = useState<TicketPriority>(ticket.priority);
  const [category, setCategory] = useState<TicketCategory>(ticket.category);
  const [assigneeEmail, setAssigneeEmail] = useState<string>(ticket.assigneeEmail || INITIAL_AGENTS[0].email);
  const [resolutionDetails, setResolutionDetails] = useState<string>(ticket.resolutionDetails || '');

  // AI assistant loading state
  const [aiLoading, setAiLoading] = useState(false);
  const [aiDraftNotes, setAiDraftNotes] = useState('');

  // Comment state
  const [commentText, setCommentText] = useState('');
  const [isInternalComment, setIsInternalComment] = useState(false);
  const [commentSubmitting, setCommentSubmitting] = useState(false);

  // Status saving loading state
  const [savingStatus, setSavingStatus] = useState(false);

  // Handle AI Auto-Triage
  const handleAiTriage = async () => {
    setAiLoading(true);
    try {
      const res = await fetch('/api/ai/triage', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ title: ticket.title, description: ticket.description }),
      });
      const data = await res.json();
      if (data.category) setCategory(data.category as TicketCategory);
      if (data.priority) setPriority(data.priority as TicketPriority);
      if (data.suggestedFix) {
        setResolutionDetails((prev) => (prev ? `${prev}\n\n[AI Diagnostic]: ${data.suggestedFix}` : `[AI Diagnostic]: ${data.suggestedFix}`));
      }
    } catch (err) {
      console.error(err);
    } finally {
      setAiLoading(false);
    }
  };

  // Handle AI Draft Resolution
  const handleAiDraftResolution = async () => {
    setAiLoading(true);
    try {
      const assignedAgent = INITIAL_AGENTS.find((a) => a.email === assigneeEmail);
      const res = await fetch('/api/ai/draft-resolution', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ticketTitle: ticket.title,
          ticketDescription: ticket.description,
          roughNotes: aiDraftNotes || resolutionDetails,
          agentName: assignedAgent?.name || 'IT Specialist',
        }),
      });
      const data = await res.json();
      if (data.resolutionDetails) {
        setResolutionDetails(data.resolutionDetails);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setAiLoading(false);
    }
  };

  // Save changes / Mark resolved
  const handleSaveUpdates = async (newStatus?: TicketStatus) => {
    setSavingStatus(true);
    const targetStatus = newStatus || status;
    const agent = INITIAL_AGENTS.find((a) => a.email === assigneeEmail);

    await onUpdateTicket(ticket.id, {
      status: targetStatus,
      assigneeName: agent?.name,
      assigneeEmail: agent?.email,
      priority,
      category,
      resolutionDetails,
    });

    setSavingStatus(false);
  };

  // Submit comment
  const handleCommentSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!commentText.trim()) return;

    setCommentSubmitting(true);
    const isAgent = currentUserRole === 'IT_ADMIN';

    await onAddComment(ticket.id, {
      authorName: isAgent ? 'Sarah Chen (IT Staff)' : ticket.employeeName,
      authorEmail: isAgent ? 'sarah.chen@enterprise.com' : ticket.employeeEmail,
      authorRole: isAgent ? 'IT_AGENT' : 'EMPLOYEE',
      message: commentText,
      isInternalOnly: isAgent ? isInternalComment : false,
    });

    setCommentText('');
    setCommentSubmitting(false);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
      <div className="bg-white w-full max-w-4xl rounded-2xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[92vh]">
        {/* Header Bar */}
        <div className="bg-slate-900 text-white p-5 flex items-center justify-between border-b border-slate-800">
          <div className="flex items-center space-x-3">
            <span className="font-mono text-xs font-bold bg-blue-600/30 border border-blue-500/40 text-blue-300 px-3 py-1 rounded-lg">
              {ticket.id}
            </span>
            <div>
              <h2 className="text-base font-bold text-white line-clamp-1">{ticket.title}</h2>
              <p className="text-xs text-slate-400">
                Submitted by {ticket.employeeName} ({ticket.department})
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-6 grid grid-cols-1 lg:grid-cols-3 gap-6 text-xs">
          {/* Main Solver & Discussion Column */}
          <div className="lg:col-span-2 space-y-6">
            {/* Issue Description Box */}
            <div className="bg-slate-50 p-4 rounded-xl border border-slate-200/80 space-y-2">
              <div className="flex items-center justify-between text-slate-500 font-medium">
                <span>Issue Description & Details</span>
                <span>Logged {new Date(ticket.createdAt).toLocaleString()}</span>
              </div>
              <p className="text-slate-800 text-xs font-medium leading-relaxed whitespace-pre-line">
                {ticket.description}
              </p>

              {ticket.locationOrDevice && (
                <p className="text-[11px] text-slate-500 pt-2 border-t border-slate-200/60">
                  📍 <strong>Device/Location:</strong> {ticket.locationOrDevice}
                </p>
              )}

              {/* Attachments */}
              {ticket.attachments && ticket.attachments.length > 0 && (
                <div className="pt-2 border-t border-slate-200/60 flex flex-wrap gap-2">
                  {ticket.attachments.map((att) => (
                    <div key={att.id} className="flex items-center space-x-1.5 bg-white border border-slate-200 px-2.5 py-1 rounded-md text-[11px]">
                      <Paperclip className="w-3 h-3 text-blue-600" />
                      <span className="font-medium text-slate-700">{att.name}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* IT Solver / Resolution Form (For IT Admins or Viewing Resolution) */}
            <div className="bg-gradient-to-br from-slate-50 to-emerald-50/30 p-5 rounded-2xl border border-emerald-200/80 space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-bold text-slate-900 flex items-center space-x-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  <span>Resolution Details & Action Summary</span>
                </h3>

                <button
                  type="button"
                  onClick={handleAiDraftResolution}
                  disabled={aiLoading}
                  className="bg-indigo-50 hover:bg-indigo-100 text-indigo-700 font-semibold px-3 py-1 rounded-lg border border-indigo-200 flex items-center space-x-1 transition-colors"
                >
                  <Sparkles className="w-3.5 h-3.5 text-indigo-600" />
                  <span>{aiLoading ? 'AI Generating...' : '✨ AI Draft Resolution Report'}</span>
                </button>
              </div>

              {currentUserRole === 'IT_ADMIN' && (
                <input
                  type="text"
                  placeholder="Optional rough notes for AI resolution drafting (e.g. reset MFA, cleared keychain)..."
                  value={aiDraftNotes}
                  onChange={(e) => setAiDraftNotes(e.target.value)}
                  className="w-full px-3 py-1.5 text-xs bg-white border border-slate-200 rounded-lg outline-hidden"
                />
              )}

              <textarea
                rows={4}
                placeholder="Enter step-by-step resolution details here. These will be automatically emailed to the employee upon closing the ticket..."
                value={resolutionDetails}
                onChange={(e) => setResolutionDetails(e.target.value)}
                readOnly={currentUserRole !== 'IT_ADMIN'}
                className="w-full p-3 text-xs bg-white border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500 outline-hidden font-mono"
              />

              {currentUserRole === 'IT_ADMIN' && (
                <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-slate-200/60">
                  <span className="text-[11px] text-slate-500">
                    📧 Saving as <strong>RESOLVED</strong> auto-dispatches resolution notice email.
                  </span>

                  <div className="flex items-center space-x-2">
                    <button
                      type="button"
                      onClick={() => handleSaveUpdates()}
                      disabled={savingStatus}
                      className="bg-slate-800 hover:bg-slate-900 text-white font-semibold px-4 py-2 rounded-xl text-xs"
                    >
                      Save Progress
                    </button>

                    <button
                      type="button"
                      onClick={() => handleSaveUpdates('RESOLVED')}
                      disabled={savingStatus}
                      className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold px-5 py-2 rounded-xl text-xs shadow-md shadow-emerald-600/20 flex items-center space-x-1.5"
                    >
                      <Check className="w-4 h-4" />
                      <span>Mark Resolved & Auto-Send Email</span>
                    </button>
                  </div>
                </div>
              )}
            </div>

            {/* Comments & Activity Log */}
            <div className="space-y-4">
              <h3 className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center space-x-2">
                <MessageSquare className="w-4 h-4 text-blue-600" />
                <span>Ticket Discussion & Updates ({ticket.comments.length})</span>
              </h3>

              {/* Comment Feed */}
              <div className="space-y-3 max-h-60 overflow-y-auto pr-1">
                {ticket.comments.length === 0 ? (
                  <p className="text-slate-400 italic text-xs">No comments added yet.</p>
                ) : (
                  ticket.comments.map((c) => (
                    <div
                      key={c.id}
                      className={`p-3 rounded-xl border text-xs ${
                        c.isInternalOnly
                          ? 'bg-amber-50/80 border-amber-200 text-amber-900'
                          : c.authorRole === 'IT_AGENT'
                          ? 'bg-blue-50/80 border-blue-200 text-slate-800'
                          : 'bg-white border-slate-200 text-slate-800'
                      }`}
                    >
                      <div className="flex items-center justify-between font-bold mb-1">
                        <span className="flex items-center space-x-1.5">
                          <span>{c.authorName}</span>
                          {c.isInternalOnly && (
                            <span className="bg-amber-200 text-amber-800 text-[10px] px-1.5 rounded-xs flex items-center space-x-0.5">
                              <Lock className="w-2.5 h-2.5" />
                              <span>Internal Note</span>
                            </span>
                          )}
                        </span>
                        <span className="text-[10px] text-slate-400 font-normal">
                          {new Date(c.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </span>
                      </div>
                      <p className="leading-relaxed">{c.message}</p>
                    </div>
                  ))
                )}
              </div>

              {/* Add Comment Form */}
              <form onSubmit={handleCommentSubmit} className="space-y-2 pt-2 border-t border-slate-100">
                <textarea
                  rows={2}
                  placeholder="Type a response or update note..."
                  value={commentText}
                  onChange={(e) => setCommentText(e.target.value)}
                  className="w-full p-2.5 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 outline-hidden"
                />

                <div className="flex items-center justify-between">
                  {currentUserRole === 'IT_ADMIN' && (
                    <label className="flex items-center space-x-2 text-slate-600 text-[11px] cursor-pointer">
                      <input
                        type="checkbox"
                        checked={isInternalComment}
                        onChange={(e) => setIsInternalComment(e.target.checked)}
                        className="rounded-xs text-amber-600 focus:ring-amber-500"
                      />
                      <span>Internal IT Note (hidden from employee)</span>
                    </label>
                  )}

                  <button
                    type="submit"
                    disabled={commentSubmitting || !commentText.trim()}
                    className="ml-auto bg-blue-600 hover:bg-blue-700 text-white font-semibold px-4 py-1.5 rounded-lg text-xs flex items-center space-x-1"
                  >
                    <Send className="w-3.5 h-3.5" />
                    <span>Post Message</span>
                  </button>
                </div>
              </form>
            </div>
          </div>

          {/* Right Column: Ticket Metadata & Controls */}
          <div className="space-y-5">
            {/* AI Auto-Triage Tool Card */}
            {currentUserRole === 'IT_ADMIN' && (
              <div className="bg-slate-900 text-white p-4 rounded-xl shadow-xs space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-cyan-400 flex items-center space-x-1.5">
                    <Zap className="w-4 h-4 text-cyan-400" />
                    <span>Gemini AI Auto-Triage</span>
                  </span>
                  <button
                    type="button"
                    onClick={handleAiTriage}
                    disabled={aiLoading}
                    className="text-[10px] bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold px-2.5 py-1 rounded-md transition-colors"
                  >
                    {aiLoading ? 'Analyzing...' : 'Run AI Analysis'}
                  </button>
                </div>
                <p className="text-[11px] text-slate-300">
                  Automatically categorize issue, calculate priority score, and generate troubleshooting notes.
                </p>
              </div>
            )}

            {/* Ticket Controls Panel */}
            <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs space-y-4">
              <h3 className="font-bold text-slate-900 border-b border-slate-100 pb-2 text-xs">
                Ticket Control Panel
              </h3>

              {/* Status Selector */}
              <div>
                <label className="block text-[11px] font-semibold text-slate-500 mb-1">Current Status</label>
                <select
                  value={status}
                  onChange={(e) => setStatus(e.target.value as TicketStatus)}
                  disabled={currentUserRole !== 'IT_ADMIN'}
                  className="w-full px-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg font-bold text-slate-800"
                >
                  <option value="NEW">NEW</option>
                  <option value="IN_PROGRESS">IN PROGRESS</option>
                  <option value="PENDING_USER">PENDING USER</option>
                  <option value="RESOLVED">RESOLVED</option>
                  <option value="CLOSED">CLOSED</option>
                </select>
              </div>

              {/* Priority Selector */}
              <div>
                <label className="block text-[11px] font-semibold text-slate-500 mb-1">Priority Level</label>
                <select
                  value={priority}
                  onChange={(e) => setPriority(e.target.value as TicketPriority)}
                  disabled={currentUserRole !== 'IT_ADMIN'}
                  className="w-full px-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg font-bold text-slate-800"
                >
                  <option value="LOW">LOW</option>
                  <option value="MEDIUM">MEDIUM</option>
                  <option value="HIGH">HIGH</option>
                  <option value="CRITICAL">CRITICAL</option>
                </select>
              </div>

              {/* Category Selector */}
              <div>
                <label className="block text-[11px] font-semibold text-slate-500 mb-1">Category</label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value as TicketCategory)}
                  disabled={currentUserRole !== 'IT_ADMIN'}
                  className="w-full px-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg font-medium text-slate-800"
                >
                  <option value="Hardware">Hardware</option>
                  <option value="Software">Software</option>
                  <option value="Network & VPN">Network & VPN</option>
                  <option value="Access & Passwords">Access & Passwords</option>
                  <option value="Security & Compliance">Security & Compliance</option>
                  <option value="Printing & Audio/Visual">Printing & Audio/Visual</option>
                  <option value="Other">Other</option>
                </select>
              </div>

              {/* Assignee Selector */}
              <div>
                <label className="block text-[11px] font-semibold text-slate-500 mb-1">Assigned IT Specialist</label>
                <select
                  value={assigneeEmail}
                  onChange={(e) => setAssigneeEmail(e.target.value)}
                  disabled={currentUserRole !== 'IT_ADMIN'}
                  className="w-full px-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg font-medium text-slate-800"
                >
                  {INITIAL_AGENTS.map((agent) => (
                    <option key={agent.id} value={agent.email}>
                      {agent.name} ({agent.role})
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Audit History Timeline */}
            <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs space-y-3">
              <h3 className="font-bold text-slate-900 border-b border-slate-100 pb-2 text-xs flex items-center space-x-1.5">
                <History className="w-3.5 h-3.5 text-slate-500" />
                <span>Audit Trail & Lifecycle</span>
              </h3>

              <div className="space-y-2">
                {ticket.history.map((h) => (
                  <div key={h.id} className="text-[11px] border-l-2 border-blue-500 pl-2 py-0.5 space-y-0.5">
                    <p className="font-semibold text-slate-800">
                      Status: {h.fromStatus} → {h.toStatus}
                    </p>
                    <p className="text-slate-400">
                      By {h.updatedBy} • {new Date(h.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
