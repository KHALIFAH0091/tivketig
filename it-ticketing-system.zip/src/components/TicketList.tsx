import React, { useState } from 'react';
import { Ticket, TicketStatus, TicketPriority, TicketCategory } from '../types';
import {
  Search,
  Filter,
  Kanban,
  List,
  User,
  Clock,
  AlertTriangle,
  CheckCircle2,
  Sparkles,
  ArrowRight,
  MoreVertical,
  ChevronRight,
  Zap,
} from 'lucide-react';

interface TicketListProps {
  tickets: Ticket[];
  onSelectTicket: (ticket: Ticket) => void;
  selectedStatus: string;
  setSelectedStatus: (status: string) => void;
  selectedPriority: string;
  setSelectedPriority: (priority: string) => void;
  selectedCategory: string;
  setSelectedCategory: (category: string) => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
}

export const TicketList: React.FC<TicketListProps> = ({
  tickets,
  onSelectTicket,
  selectedStatus,
  setSelectedStatus,
  selectedPriority,
  setSelectedPriority,
  selectedCategory,
  setSelectedCategory,
  searchQuery,
  setSearchQuery,
}) => {
  const [viewMode, setViewMode] = useState<'LIST' | 'KANBAN'>('LIST');

  const statusOptions = ['ALL', 'NEW', 'IN_PROGRESS', 'PENDING_USER', 'RESOLVED', 'CLOSED'];
  const priorityOptions = ['ALL', 'CRITICAL', 'HIGH', 'MEDIUM', 'LOW'];
  const categoryOptions = [
    'ALL',
    'Hardware',
    'Software',
    'Network & VPN',
    'Access & Passwords',
    'Security & Compliance',
    'Printing & Audio/Visual',
    'Other',
  ];

  // Helper for priority badges
  const getPriorityBadge = (p: TicketPriority) => {
    switch (p) {
      case 'CRITICAL':
        return <span className="bg-red-50 text-red-700 border border-red-200 text-[10px] font-bold px-2 py-0.5 rounded-full">CRITICAL</span>;
      case 'HIGH':
        return <span className="bg-amber-50 text-amber-700 border border-amber-200 text-[10px] font-bold px-2 py-0.5 rounded-full">HIGH</span>;
      case 'MEDIUM':
        return <span className="bg-blue-50 text-blue-700 border border-blue-200 text-[10px] font-bold px-2 py-0.5 rounded-full">MEDIUM</span>;
      default:
        return <span className="bg-slate-100 text-slate-600 border border-slate-200 text-[10px] font-medium px-2 py-0.5 rounded-full">LOW</span>;
    }
  };

  // Helper for status badges
  const getStatusBadge = (s: TicketStatus) => {
    switch (s) {
      case 'NEW':
        return <span className="bg-blue-100 text-blue-800 font-bold text-[10px] px-2.5 py-0.5 rounded-full">NEW</span>;
      case 'IN_PROGRESS':
        return <span className="bg-amber-100 text-amber-800 font-bold text-[10px] px-2.5 py-0.5 rounded-full">IN PROGRESS</span>;
      case 'PENDING_USER':
        return <span className="bg-purple-100 text-purple-800 font-bold text-[10px] px-2.5 py-0.5 rounded-full">PENDING USER</span>;
      case 'RESOLVED':
        return <span className="bg-emerald-100 text-emerald-800 font-bold text-[10px] px-2.5 py-0.5 rounded-full">RESOLVED</span>;
      case 'CLOSED':
        return <span className="bg-slate-100 text-slate-700 font-bold text-[10px] px-2.5 py-0.5 rounded-full">CLOSED</span>;
    }
  };

  return (
    <div className="space-y-4">
      {/* Search, Filter & View Mode Controls Bar */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs space-y-3">
        <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
          {/* Search Box */}
          <div className="relative flex-1">
            <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
            <input
              type="text"
              placeholder="Search by ticket ID, title, description, employee name..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-4 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 outline-hidden"
            />
          </div>

          {/* Filters */}
          <div className="flex flex-wrap items-center gap-2">
            {/* Category Dropdown */}
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="px-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 outline-hidden text-slate-700 font-medium"
            >
              {categoryOptions.map((cat) => (
                <option key={cat} value={cat}>
                  Category: {cat}
                </option>
              ))}
            </select>

            {/* Priority Dropdown */}
            <select
              value={selectedPriority}
              onChange={(e) => setSelectedPriority(e.target.value)}
              className="px-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 outline-hidden text-slate-700 font-medium"
            >
              {priorityOptions.map((p) => (
                <option key={p} value={p}>
                  Priority: {p}
                </option>
              ))}
            </select>

            {/* View Mode Toggle */}
            <div className="flex bg-slate-100 p-0.5 rounded-xl border border-slate-200">
              <button
                onClick={() => setViewMode('LIST')}
                className={`p-1.5 rounded-lg text-xs font-semibold ${
                  viewMode === 'LIST' ? 'bg-white text-blue-600 shadow-xs' : 'text-slate-500 hover:text-slate-900'
                }`}
                title="List View"
              >
                <List className="w-4 h-4" />
              </button>
              <button
                onClick={() => setViewMode('KANBAN')}
                className={`p-1.5 rounded-lg text-xs font-semibold ${
                  viewMode === 'KANBAN' ? 'bg-white text-blue-600 shadow-xs' : 'text-slate-500 hover:text-slate-900'
                }`}
                title="Kanban Board View"
              >
                <Kanban className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>

        {/* Status Filter Pills */}
        <div className="flex items-center space-x-1.5 overflow-x-auto pt-1 border-t border-slate-100 text-xs scrollbar-none">
          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider mr-2">Status:</span>
          {statusOptions.map((st) => (
            <button
              key={st}
              onClick={() => setSelectedStatus(st)}
              className={`px-3 py-1 rounded-lg text-xs font-semibold transition-colors whitespace-nowrap ${
                selectedStatus === st
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              {st === 'ALL' ? 'All Tickets' : st.replace('_', ' ')}
            </button>
          ))}
        </div>
      </div>

      {/* VIEW MODE 1: TABLE / LIST */}
      {viewMode === 'LIST' && (
        <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
          {tickets.length === 0 ? (
            <div className="p-12 text-center text-slate-500">
              <Clock className="w-8 h-8 text-slate-300 mx-auto mb-2" />
              <p className="text-sm font-semibold">No tickets found matching current filters.</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-200 text-[11px] font-bold text-slate-500 uppercase tracking-wider">
                    <th className="py-3 px-4">Ticket ID & Title</th>
                    <th className="py-3 px-4">Category</th>
                    <th className="py-3 px-4">Employee & Dept</th>
                    <th className="py-3 px-4">Priority</th>
                    <th className="py-3 px-4">Status</th>
                    <th className="py-3 px-4">Assignee</th>
                    <th className="py-3 px-4 text-right">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-xs">
                  {tickets.map((t) => (
                    <tr
                      key={t.id}
                      onClick={() => onSelectTicket(t)}
                      className="hover:bg-slate-50/80 cursor-pointer transition-colors group"
                    >
                      <td className="py-3.5 px-4">
                        <div className="flex items-center space-x-2.5">
                          <span className="font-mono text-xs font-bold text-slate-900 bg-slate-100 px-2 py-0.5 rounded-md border border-slate-200">
                            {t.id}
                          </span>
                          <div>
                            <p className="font-bold text-slate-900 group-hover:text-blue-600 transition-colors">
                              {t.title}
                            </p>
                            <p className="text-[11px] text-slate-400">
                              Logged {new Date(t.createdAt).toLocaleDateString()}
                            </p>
                          </div>
                        </div>
                      </td>

                      <td className="py-3.5 px-4 font-medium text-slate-600">{t.category}</td>

                      <td className="py-3.5 px-4">
                        <p className="font-semibold text-slate-800">{t.employeeName}</p>
                        <p className="text-[11px] text-slate-400">{t.department}</p>
                      </td>

                      <td className="py-3.5 px-4">{getPriorityBadge(t.priority)}</td>

                      <td className="py-3.5 px-4">{getStatusBadge(t.status)}</td>

                      <td className="py-3.5 px-4">
                        {t.assigneeName ? (
                          <span className="text-slate-700 font-medium flex items-center space-x-1">
                            <User className="w-3.5 h-3.5 text-slate-400" />
                            <span>{t.assigneeName}</span>
                          </span>
                        ) : (
                          <span className="text-slate-400 italic">Unassigned</span>
                        )}
                      </td>

                      <td className="py-3.5 px-4 text-right">
                        <button className="bg-slate-100 group-hover:bg-blue-600 group-hover:text-white text-slate-700 px-3 py-1 rounded-lg text-xs font-semibold transition-colors flex items-center space-x-1 ml-auto">
                          <span>Solve / Review</span>
                          <ChevronRight className="w-3 h-3" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* VIEW MODE 2: KANBAN BOARD */}
      {viewMode === 'KANBAN' && (
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          {(['NEW', 'IN_PROGRESS', 'PENDING_USER', 'RESOLVED'] as TicketStatus[]).map((colStatus) => {
            const colTickets = tickets.filter((t) => t.status === colStatus);
            return (
              <div key={colStatus} className="bg-slate-100/70 p-3 rounded-2xl border border-slate-200/80 space-y-3 min-h-[400px]">
                <div className="flex items-center justify-between px-2 pt-1">
                  <span className="font-bold text-xs uppercase text-slate-600 tracking-wider">
                    {colStatus.replace('_', ' ')}
                  </span>
                  <span className="bg-slate-200 text-slate-700 font-bold text-[10px] px-2 py-0.5 rounded-full">
                    {colTickets.length}
                  </span>
                </div>

                <div className="space-y-3">
                  {colTickets.map((t) => (
                    <div
                      key={t.id}
                      onClick={() => onSelectTicket(t)}
                      className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs hover:shadow-md cursor-pointer transition-all space-y-3"
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-mono text-[10px] font-bold text-slate-700 bg-slate-100 px-2 py-0.5 rounded">
                          {t.id}
                        </span>
                        {getPriorityBadge(t.priority)}
                      </div>

                      <h4 className="font-bold text-xs text-slate-900 line-clamp-2 leading-snug">{t.title}</h4>

                      <div className="text-[11px] text-slate-500 border-t border-slate-100 pt-2 flex items-center justify-between">
                        <span>{t.employeeName}</span>
                        <span className="font-semibold text-blue-600">{t.category}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
