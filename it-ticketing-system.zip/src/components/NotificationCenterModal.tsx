import React, { useState } from 'react';
import { NotificationLog } from '../types';
import { X, Mail, Search, CheckCircle, Clock, FileCode, ArrowRight, Eye, ShieldCheck, RefreshCcw } from 'lucide-react';

interface NotificationCenterModalProps {
  notifications: NotificationLog[];
  onClose: () => void;
}

export const NotificationCenterModal: React.FC<NotificationCenterModalProps> = ({ notifications, onClose }) => {
  const [selectedNotif, setSelectedNotif] = useState<NotificationLog | null>(notifications[0] || null);
  const [search, setSearch] = useState('');

  const filtered = notifications.filter(
    (n) =>
      n.ticketId.toLowerCase().includes(search.toLowerCase()) ||
      n.recipientEmail.toLowerCase().includes(search.toLowerCase()) ||
      n.subject.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6 overflow-hidden">
      <div className="bg-white w-full max-w-5xl h-[85vh] rounded-2xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col">
        {/* Header */}
        <div className="bg-slate-900 text-white p-5 flex items-center justify-between border-b border-slate-800">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-indigo-600 rounded-xl text-white">
              <Mail className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white flex items-center space-x-2">
                <span>Automated Email Dispatch Outbox</span>
                <span className="bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-[10px] font-bold px-2 py-0.5 rounded-full">
                  Real-time Delivery Logs
                </span>
              </h2>
              <p className="text-xs text-slate-400">
                Inspect automated status update notifications and resolution details sent to internal employees.
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Layout */}
        <div className="flex-1 grid grid-cols-1 md:grid-cols-12 overflow-hidden">
          {/* Left List Pane */}
          <div className="md:col-span-5 border-r border-slate-200 bg-slate-50/50 flex flex-col overflow-hidden">
            {/* Search Box */}
            <div className="p-3 border-b border-slate-200 bg-white">
              <div className="relative">
                <Search className="w-3.5 h-3.5 absolute left-3 top-2.5 text-slate-400" />
                <input
                  type="text"
                  placeholder="Filter email logs..."
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  className="w-full pl-8 pr-3 py-1.5 text-xs bg-slate-100 border border-slate-200 rounded-lg outline-hidden"
                />
              </div>
            </div>

            {/* Notification List */}
            <div className="flex-1 overflow-y-auto divide-y divide-slate-100 p-2 space-y-1">
              {filtered.length === 0 ? (
                <p className="p-6 text-center text-xs text-slate-400">No email logs found.</p>
              ) : (
                filtered.map((notif) => {
                  const isSelected = selectedNotif?.id === notif.id;
                  return (
                    <div
                      key={notif.id}
                      onClick={() => setSelectedNotif(notif)}
                      className={`p-3 rounded-xl cursor-pointer transition-all border text-xs space-y-1 ${
                        isSelected
                          ? 'bg-white border-indigo-500 shadow-xs ring-1 ring-indigo-500/20'
                          : 'bg-white/60 hover:bg-white border-transparent'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-mono text-[10px] font-bold text-slate-700 bg-slate-100 px-2 py-0.5 rounded">
                          {notif.ticketId}
                        </span>
                        <span className="text-[10px] text-emerald-700 font-bold bg-emerald-50 px-2 py-0.5 rounded-full flex items-center space-x-1">
                          <CheckCircle className="w-2.5 h-2.5" />
                          <span>DELIVERED</span>
                        </span>
                      </div>

                      <p className="font-bold text-slate-900 line-clamp-1">{notif.subject}</p>
                      <div className="flex items-center justify-between text-[11px] text-slate-500 pt-1">
                        <span>To: {notif.recipientEmail}</span>
                        <span>{new Date(notif.sentAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>

          {/* Right Preview Pane */}
          <div className="md:col-span-7 bg-white flex flex-col overflow-hidden">
            {selectedNotif ? (
              <div className="flex-1 flex flex-col overflow-hidden">
                {/* Email Metadata Header */}
                <div className="p-4 border-b border-slate-200 bg-slate-50/80 space-y-2 text-xs">
                  <div className="flex items-center justify-between">
                    <span className="font-semibold text-slate-500">
                      Subject: <strong className="text-slate-900">{selectedNotif.subject}</strong>
                    </span>
                    <span className="text-[11px] text-slate-400">
                      {new Date(selectedNotif.sentAt).toLocaleString()}
                    </span>
                  </div>

                  <div className="flex items-center justify-between text-[11px] text-slate-600">
                    <span>
                      Recipient: <strong>{selectedNotif.recipientName}</strong> &lt;{selectedNotif.recipientEmail}&gt;
                    </span>
                    <span>
                      Sender: <strong>IT Dispatch Service</strong> &lt;no-reply@enterprise.com&gt;
                    </span>
                  </div>
                </div>

                {/* Rendered HTML Email Body */}
                <div className="flex-1 p-6 overflow-y-auto bg-slate-100/50 flex justify-center">
                  <div
                    className="w-full max-w-xl bg-white rounded-xl shadow-xs border border-slate-200/80 overflow-hidden"
                    dangerouslySetInnerHTML={{ __html: selectedNotif.bodyHtml }}
                  />
                </div>
              </div>
            ) : (
              <div className="flex-1 flex items-center justify-center text-xs text-slate-400">
                Select an email log on the left to preview formatted HTML output.
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
