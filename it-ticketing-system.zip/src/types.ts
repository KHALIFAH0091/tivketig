export type TicketStatus = 'NEW' | 'IN_PROGRESS' | 'PENDING_USER' | 'RESOLVED' | 'CLOSED';

export type TicketPriority = 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';

export type TicketCategory =
  | 'Hardware'
  | 'Software'
  | 'Network & VPN'
  | 'Access & Passwords'
  | 'Security & Compliance'
  | 'Printing & Audio/Visual'
  | 'Other';

export interface TicketComment {
  id: string;
  authorName: string;
  authorEmail: string;
  authorRole: 'EMPLOYEE' | 'IT_AGENT' | 'SYSTEM';
  message: string;
  timestamp: string;
  isInternalOnly?: boolean;
}

export interface TicketStatusHistory {
  id: string;
  fromStatus: TicketStatus;
  toStatus: TicketStatus;
  updatedBy: string;
  timestamp: string;
  note?: string;
}

export interface TicketAttachment {
  id: string;
  name: string;
  size: string;
  type: string;
  url?: string;
}

export interface Ticket {
  id: string; // e.g. "TICK-1024"
  title: string;
  description: string;
  employeeName: string;
  employeeEmail: string;
  department: string;
  locationOrDevice?: string;
  category: TicketCategory;
  priority: TicketPriority;
  status: TicketStatus;
  assigneeName?: string;
  assigneeEmail?: string;
  createdAt: string;
  updatedAt: string;
  closedAt?: string;
  resolutionDetails?: string;
  attachments?: TicketAttachment[];
  comments: TicketComment[];
  history: TicketStatusHistory[];
  rating?: number; // 1-5 stars CSAT
  ratingFeedback?: string;
  aiTriaged?: boolean;
  aiSuggestedFix?: string;
}

export interface NotificationLog {
  id: string;
  ticketId: string;
  ticketTitle: string;
  recipientEmail: string;
  recipientName: string;
  type: 'STATUS_UPDATE' | 'TICKET_RECEIVED' | 'RESOLUTION_DETAILS' | 'COMMENT_ADDED';
  subject: string;
  bodyHtml: string;
  sentAt: string;
  status: 'DELIVERED' | 'FAILED' | 'PENDING';
}

export interface ITAgent {
  id: string;
  name: string;
  email: string;
  role: string;
  avatar: string;
  specialty: TicketCategory[];
}

export type UserRole = 'EMPLOYEE' | 'IT_ADMIN';
