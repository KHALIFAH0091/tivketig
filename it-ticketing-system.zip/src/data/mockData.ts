import { Ticket, ITAgent, NotificationLog } from '../types';

export const INITIAL_AGENTS: ITAgent[] = [
  {
    id: 'agent-1',
    name: 'Alex Rivera',
    email: 'alex.rivera@enterprise.com',
    role: 'Senior Hardware Specialist',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&q=80',
    specialty: ['Hardware', 'Printing & Audio/Visual'],
  },
  {
    id: 'agent-2',
    name: 'Sarah Chen',
    email: 'sarah.chen@enterprise.com',
    role: 'Cybersecurity & IAM Specialist',
    avatar: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&w=150&q=80',
    specialty: ['Access & Passwords', 'Security & Compliance'],
  },
  {
    id: 'agent-3',
    name: 'Marcus Vance',
    email: 'marcus.vance@enterprise.com',
    role: 'Network Operations Lead',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=150&q=80',
    specialty: ['Network & VPN', 'Software'],
  },
  {
    id: 'agent-4',
    name: 'Elena Rostova',
    email: 'elena.rostova@enterprise.com',
    role: 'IT Service Desk Manager',
    avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=150&q=80',
    specialty: ['Software', 'Other'],
  },
];

export const DEPARTMENTS = [
  'Engineering & Development',
  'Human Resources',
  'Sales & Business Dev',
  'Marketing & Communications',
  'Finance & Accounting',
  'Operations & Logistics',
  'Legal & Compliance',
  'Executive Office',
];

export const INITIAL_TICKETS: Ticket[] = [
  {
    id: 'TICK-1001',
    title: 'VPN Connection Failure on MacOS Sequoia after System Update',
    description: 'Since updating to macOS Sequoia yesterday evening, GlobalProtect VPN fails during 2FA authentication phase. Showing error code "SecTrustEvaluate error 0x80090308". Unable to access internal code repositories.',
    employeeName: 'David Miller',
    employeeEmail: 'david.miller@enterprise.com',
    department: 'Engineering & Development',
    locationOrDevice: 'MacBook Pro 16" (Tag: MBP-2024-889)',
    category: 'Network & VPN',
    priority: 'HIGH',
    status: 'IN_PROGRESS',
    assigneeName: 'Marcus Vance',
    assigneeEmail: 'marcus.vance@enterprise.com',
    createdAt: new Date(Date.now() - 1000 * 60 * 60 * 18).toISOString(), // 18h ago
    updatedAt: new Date(Date.now() - 1000 * 60 * 60 * 2).toISOString(),
    aiTriaged: true,
    aiSuggestedFix: 'Certificate store path changed in latest macOS build. Clear GlobalProtect keychain entries and reinstall profile certificate.',
    comments: [
      {
        id: 'c-1',
        authorName: 'David Miller',
        authorEmail: 'david.miller@enterprise.com',
        authorRole: 'EMPLOYEE',
        message: 'Submitted issue request with attached error log screenshot.',
        timestamp: new Date(Date.now() - 1000 * 60 * 60 * 18).toISOString(),
      },
      {
        id: 'c-2',
        authorName: 'Marcus Vance',
        authorEmail: 'marcus.vance@enterprise.com',
        authorRole: 'IT_AGENT',
        message: 'Hi David, I have updated your VPN profile on the gateway side. Could you please clear your local VPN app cache and retry connection?',
        timestamp: new Date(Date.now() - 1000 * 60 * 60 * 2).toISOString(),
      }
    ],
    history: [
      {
        id: 'h-1',
        fromStatus: 'NEW',
        toStatus: 'IN_PROGRESS',
        updatedBy: 'Marcus Vance',
        timestamp: new Date(Date.now() - 1000 * 60 * 60 * 12).toISOString(),
        note: 'Assigned to Marcus Vance and initiated VPN certificate reset.',
      }
    ]
  },
  {
    id: 'TICK-1002',
    title: 'Dual 4K Monitor Flickering & DisplayPort Audio Loss',
    description: 'Workstation Dell Thunderbolt Dock WD19TBS output keeps flickering every 30 seconds when both 4K screens are connected. Primary monitor flickers and audio output drops intermittently.',
    employeeName: 'Sophia Taylor',
    employeeEmail: 'sophia.taylor@enterprise.com',
    department: 'Marketing & Communications',
    locationOrDevice: 'Desk 4B - Office 302',
    category: 'Hardware',
    priority: 'MEDIUM',
    status: 'NEW',
    assigneeName: 'Alex Rivera',
    assigneeEmail: 'alex.rivera@enterprise.com',
    createdAt: new Date(Date.now() - 1000 * 60 * 60 * 5).toISOString(),
    updatedAt: new Date(Date.now() - 1000 * 60 * 60 * 5).toISOString(),
    aiTriaged: true,
    aiSuggestedFix: 'Docking station firmware update required for DisplayPort MST hub stability. Verify Thunderbolt cable power delivery.',
    comments: [],
    history: []
  },
  {
    id: 'TICK-1003',
    title: 'Okta 2FA Account Locked & Single Sign-On Expiration',
    description: 'Locked out of Okta SSO after changing mobile device. Authenticator push notifications are going to old registered phone. Need MFA device reset for new iPhone 16.',
    employeeName: 'James Wilson',
    employeeEmail: 'james.wilson@enterprise.com',
    department: 'Finance & Accounting',
    locationOrDevice: 'Remote - Finance Dept',
    category: 'Access & Passwords',
    priority: 'CRITICAL',
    status: 'RESOLVED',
    assigneeName: 'Sarah Chen',
    assigneeEmail: 'sarah.chen@enterprise.com',
    createdAt: new Date(Date.now() - 1000 * 60 * 60 * 28).toISOString(),
    updatedAt: new Date(Date.now() - 1000 * 60 * 60 * 1).toISOString(),
    resolutionDetails: 'Verified employee identity via security questions and voice verification. Revoked old MFA token on Okta Admin Console. Issued temporary 24-hour enrollment link to james.wilson@enterprise.com. Verified employee successfully registered new Okta Verify device.',
    aiTriaged: true,
    rating: 5,
    ratingFeedback: 'Super fast response by Sarah! Reset my Okta MFA in under 15 minutes. Thank you so much!',
    comments: [
      {
        id: 'c-3',
        authorName: 'Sarah Chen',
        authorEmail: 'sarah.chen@enterprise.com',
        authorRole: 'IT_AGENT',
        message: 'Identity verified. MFA reset link dispatched via secure email.',
        timestamp: new Date(Date.now() - 1000 * 60 * 60 * 2).toISOString(),
      }
    ],
    history: [
      {
        id: 'h-2',
        fromStatus: 'NEW',
        toStatus: 'IN_PROGRESS',
        updatedBy: 'Sarah Chen',
        timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24).toISOString(),
      },
      {
        id: 'h-3',
        fromStatus: 'IN_PROGRESS',
        toStatus: 'RESOLVED',
        updatedBy: 'Sarah Chen',
        timestamp: new Date(Date.now() - 1000 * 60 * 60 * 1).toISOString(),
        note: 'MFA reset complete. Resolution details email dispatched automatically to employee.',
      }
    ]
  },
  {
    id: 'TICK-1004',
    title: 'Figma Enterprise License Provisioning Request',
    description: 'New Senior UI Designer onboarded today. Requires Figma Organization Seat with Dev Mode enabled for design system management.',
    employeeName: 'Emily Zhang',
    employeeEmail: 'emily.zhang@enterprise.com',
    department: 'Human Resources',
    locationOrDevice: 'HQ Floor 2',
    category: 'Software',
    priority: 'LOW',
    status: 'CLOSED',
    assigneeName: 'Elena Rostova',
    assigneeEmail: 'elena.rostova@enterprise.com',
    createdAt: new Date(Date.now() - 1000 * 60 * 60 * 72).toISOString(),
    updatedAt: new Date(Date.now() - 1000 * 60 * 60 * 48).toISOString(),
    closedAt: new Date(Date.now() - 1000 * 60 * 60 * 48).toISOString(),
    resolutionDetails: 'Approved manager license request. Assigned Figma Enterprise Editor & Dev Mode seat under team "Design Core". Sent invitation link to emily.zhang@enterprise.com.',
    aiTriaged: true,
    rating: 5,
    comments: [],
    history: []
  }
];

export const INITIAL_NOTIFICATIONS: NotificationLog[] = [
  {
    id: 'notif-101',
    ticketId: 'TICK-1003',
    ticketTitle: 'Okta 2FA Account Locked & Single Sign-On Expiration',
    recipientEmail: 'james.wilson@enterprise.com',
    recipientName: 'James Wilson',
    type: 'RESOLUTION_DETAILS',
    subject: '✅ Ticket [TICK-1003] Resolved: Okta 2FA Account Locked & Single Sign-On Expiration',
    sentAt: new Date(Date.now() - 1000 * 60 * 60 * 1).toISOString(),
    status: 'DELIVERED',
    bodyHtml: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; border: 1px solid #e2e8f0; border-radius: 8px; padding: 24px; background-color: #ffffff;">
        <div style="background-color: #0f172a; color: #ffffff; padding: 16px; border-radius: 6px; text-align: center; margin-bottom: 20px;">
          <h2 style="margin: 0; font-size: 20px;">Enterprise IT Support Desk</h2>
          <p style="margin: 4px 0 0 0; font-size: 13px; color: #94a3b8;">Automated Resolution & Issue Closure Notice</p>
        </div>
        <p style="font-size: 15px; color: #334155;">Hello <strong>James Wilson</strong>,</p>
        <p style="font-size: 14px; color: #475569; line-height: 1.6;">Your IT issue request <strong>[TICK-1003]</strong> has been resolved by our IT Support Specialist <strong>Sarah Chen</strong>.</p>
        
        <div style="background-color: #f8fafc; border-left: 4px solid #10b981; padding: 16px; margin: 20px 0; border-radius: 4px;">
          <h4 style="margin: 0 0 8px 0; color: #065f46; font-size: 14px;">Resolution Summary & Actions Taken:</h4>
          <p style="margin: 0; font-size: 14px; color: #1e293b; line-height: 1.5;">Verified employee identity via security questions and voice verification. Revoked old MFA token on Okta Admin Console. Issued temporary 24-hour enrollment link to james.wilson@enterprise.com. Verified employee successfully registered new Okta Verify device.</p>
        </div>

        <p style="font-size: 13px; color: #64748b;">If your issue persists or you need further help with this request, you may reply directly to this email or re-open your ticket in the IT Employee Portal within 48 hours.</p>

        <div style="margin-top: 24px; padding-top: 16px; border-top: 1px solid #e2e8f0; text-align: center;">
          <p style="font-size: 12px; color: #94a3b8; margin: 0;">This is an automated system notification from Enterprise IT Ticketing Service.</p>
        </div>
      </div>
    `
  }
];
