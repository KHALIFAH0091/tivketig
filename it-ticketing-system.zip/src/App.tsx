import React, { useState, useEffect } from 'react';
import { Ticket, NotificationLog, UserRole, TicketStatus, TicketPriority, TicketCategory } from './types';
import { Header } from './components/Header';
import { MetricsBar } from './components/MetricsBar';
import { EmployeePortal } from './components/EmployeePortal';
import { TicketList } from './components/TicketList';
import { TicketDetailModal } from './components/TicketDetailModal';
import { NotificationCenterModal } from './components/NotificationCenterModal';
import { CSATModal } from './components/CSATModal';
import { Mail, CheckCircle2, ShieldCheck, Sparkles, X } from 'lucide-react';

export default function App() {
  const [activeRole, setActiveRole] = useState<UserRole>('EMPLOYEE');
  const [tickets, setTickets] = useState<Ticket[]>([]);
  const [notifications, setNotifications] = useState<NotificationLog[]>([]);
  const [loading, setLoading] = useState<boolean>(true);

  // Filters for IT Admin workspace
  const [selectedStatus, setSelectedStatus] = useState<string>('ALL');
  const [selectedPriority, setSelectedPriority] = useState<string>('ALL');
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Modals & Drawers
  const [selectedTicket, setSelectedTicket] = useState<Ticket | null>(null);
  const [showNotificationsModal, setShowNotificationsModal] = useState<boolean>(false);
  const [ratingTicketId, setRatingTicketId] = useState<string | null>(null);

  // Live Toast Notification
  const [toastNotif, setToastNotif] = useState<NotificationLog | null>(null);

  // Fetch Tickets & Notifications
  const fetchTicketsAndNotifications = async () => {
    try {
      const [tRes, nRes] = await Promise.all([
        fetch('/api/tickets'),
        fetch('/api/notifications'),
      ]);
      if (tRes.ok) {
        const tData = await tRes.json();
        setTickets(tData);
      }
      if (nRes.ok) {
        const nData = await nRes.json();
        setNotifications(nData);
      }
    } catch (err) {
      console.error('Error fetching data:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchTicketsAndNotifications();
  }, []);

  // Show live toast when automated email is dispatched
  const triggerEmailToast = (notif: NotificationLog) => {
    setToastNotif(notif);
    setTimeout(() => {
      setToastNotif((current) => (current?.id === notif.id ? null : current));
    }, 6000);
  };

  // Submit Ticket Handler
  const handleSubmitTicket = async (ticketData: any) => {
    setLoading(true);
    try {
      const res = await fetch('/api/tickets', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(ticketData),
      });
      const data = await res.json();
      if (data.ticket) {
        await fetchTicketsAndNotifications();
        if (data.notificationSent) {
          triggerEmailToast(data.notificationSent);
        }
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  // Update Ticket Handler
  const handleUpdateTicket = async (
    ticketId: string,
    updates: {
      status?: TicketStatus;
      assigneeName?: string;
      assigneeEmail?: string;
      priority?: TicketPriority;
      category?: TicketCategory;
      resolutionDetails?: string;
    }
  ) => {
    try {
      const res = await fetch(`/api/tickets/${ticketId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updates),
      });
      const data = await res.json();
      if (data.ticket) {
        // Update local ticket view
        setSelectedTicket(data.ticket);
        await fetchTicketsAndNotifications();
        if (data.notificationSent) {
          triggerEmailToast(data.notificationSent);
        }
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Add Comment Handler
  const handleAddComment = async (
    ticketId: string,
    comment: {
      authorName: string;
      authorEmail: string;
      authorRole: 'EMPLOYEE' | 'IT_AGENT';
      message: string;
      isInternalOnly?: boolean;
    }
  ) => {
    try {
      const res = await fetch(`/api/tickets/${ticketId}/comments`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(comment),
      });
      const data = await res.json();
      if (data.ticket) {
        setSelectedTicket(data.ticket);
        await fetchTicketsAndNotifications();
        if (data.notificationSent) {
          triggerEmailToast(data.notificationSent);
        }
      }
    } catch (err) {
      console.error(err);
    }
  };

  // CSAT Rating Handler
  const handleRateTicket = async (ticketId: string, rating: number, feedback: string) => {
    try {
      const res = await fetch(`/api/tickets/${ticketId}/rate`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ rating, feedback }),
      });
      if (res.ok) {
        await fetchTicketsAndNotifications();
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Filter tickets for IT Admin view
  const filteredTickets = tickets.filter((t) => {
    if (selectedStatus !== 'ALL' && t.status !== selectedStatus) return false;
    if (selectedPriority !== 'ALL' && t.priority !== selectedPriority) return false;
    if (selectedCategory !== 'ALL' && t.category !== selectedCategory) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      return (
        t.id.toLowerCase().includes(q) ||
        t.title.toLowerCase().includes(q) ||
        t.description.toLowerCase().includes(q) ||
        t.employeeName.toLowerCase().includes(q)
      );
    }
    return true;
  });

  return (
    <div className="min-h-screen bg-slate-100 text-slate-800 font-sans flex flex-col antialiased selection:bg-blue-500 selection:text-white">
      {/* Global Toast Notification */}
      {toastNotif && (
        <div className="fixed top-20 right-4 z-50 bg-slate-900 text-white p-4 rounded-2xl shadow-2xl border border-indigo-500/50 max-w-sm animate-bounce-short">
          <div className="flex items-start justify-between space-x-3">
            <div className="p-2 bg-emerald-500/20 text-emerald-400 rounded-xl">
              <Mail className="w-5 h-5" />
            </div>
            <div className="flex-1 space-y-1">
              <div className="flex items-center space-x-2">
                <span className="text-xs font-bold text-emerald-400">Automated Email Dispatched</span>
                <span className="font-mono text-[10px] bg-slate-800 text-slate-300 px-1.5 py-0.5 rounded">
                  {toastNotif.ticketId}
                </span>
              </div>
              <p className="text-xs font-bold text-white line-clamp-1">{toastNotif.subject}</p>
              <p className="text-[11px] text-slate-400">Sent to: {toastNotif.recipientEmail}</p>
            </div>
            <button
              onClick={() => setToastNotif(null)}
              className="text-slate-400 hover:text-white"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* Header */}
      <Header
        activeRole={activeRole}
        setActiveRole={setActiveRole}
        onOpenNewTicket={() => {
          setActiveRole('EMPLOYEE');
        }}
        onOpenNotifications={() => setShowNotificationsModal(true)}
        unreadCount={notifications.length}
      />

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
        {/* Overview Metrics Header */}
        <MetricsBar tickets={tickets} notifications={notifications} />

        {/* View Switcher based on Active Role */}
        {activeRole === 'EMPLOYEE' ? (
          <EmployeePortal
            tickets={tickets}
            onSubmitTicket={handleSubmitTicket}
            onSelectTicket={(t) => setSelectedTicket(t)}
            onRateTicket={(ticketId) => setRatingTicketId(ticketId)}
            isLoading={loading}
          />
        ) : (
          <div className="space-y-4">
            <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
              <div>
                <h1 className="text-xl font-bold text-slate-900 flex items-center space-x-2">
                  <span>IT Operations Support Queue</span>
                  <span className="bg-indigo-50 border border-indigo-200 text-indigo-700 text-xs font-bold px-2.5 py-0.5 rounded-full">
                    IT Staff View
                  </span>
                </h1>
                <p className="text-xs text-slate-500 mt-0.5">
                  Manage issue queues, trigger AI triage diagnostics, draft resolution details, and close tickets with auto-emailed notices.
                </p>
              </div>

              <div className="flex items-center space-x-2 text-xs">
                <span className="text-slate-500">Active Agent:</span>
                <span className="font-bold text-slate-900 bg-slate-100 px-3 py-1 rounded-lg border border-slate-200">
                  Sarah Chen (Security & Ops)
                </span>
              </div>
            </div>

            <TicketList
              tickets={filteredTickets}
              onSelectTicket={(t) => setSelectedTicket(t)}
              selectedStatus={selectedStatus}
              setSelectedStatus={setSelectedStatus}
              selectedPriority={selectedPriority}
              setSelectedPriority={setSelectedPriority}
              selectedCategory={selectedCategory}
              setSelectedCategory={setSelectedCategory}
              searchQuery={searchQuery}
              setSearchQuery={setSearchQuery}
            />
          </div>
        )}
      </main>

      {/* Modals & Drawers */}
      {selectedTicket && (
        <TicketDetailModal
          ticket={selectedTicket}
          onClose={() => setSelectedTicket(null)}
          onUpdateTicket={handleUpdateTicket}
          onAddComment={handleAddComment}
          currentUserRole={activeRole}
        />
      )}

      {showNotificationsModal && (
        <NotificationCenterModal
          notifications={notifications}
          onClose={() => setShowNotificationsModal(false)}
        />
      )}

      {ratingTicketId && (
        <CSATModal
          ticketId={ratingTicketId}
          onClose={() => setRatingTicketId(null)}
          onSubmitRating={handleRateTicket}
        />
      )}

      {/* Footer */}
      <footer className="bg-white border-t border-slate-200 py-6 text-center text-xs text-slate-500 space-y-1">
        <p className="font-medium text-slate-700">Enterprise IT Ticketing & Resolution System</p>
        <p className="text-slate-400">Automated Status Updates • Email Notifications • AI Auto-Triaging & Resolution Generator</p>
      </footer>
    </div>
  );
}
